// Service worker: guarda o token de pareamento e fala com a API do CRM.
// As chamadas saem daqui (não do content script) para usar as host_permissions
// da extensão e evitar restrições de CORS/CSP da página.
const API_BASE = 'https://api-crm.promise.codes';

async function getToken() {
  const { pairingToken } = await chrome.storage.local.get('pairingToken');
  return pairingToken || null;
}

async function api(path, options = {}) {
  const token = await getToken();
  if (!token) throw new Error('Extensão não pareada. Cole o código no popup.');
  const res = await fetch(`${API_BASE}${path}`, {
    ...options,
    headers: {
      'Content-Type': 'application/json',
      Authorization: `Bearer ${token}`,
      ...(options.headers || {}),
    },
  });
  if (!res.ok) throw new Error(`API respondeu ${res.status}`);
  return res.status === 204 ? null : res.json();
}

chrome.runtime.onMessage.addListener((msg, _sender, sendResponse) => {
  (async () => {
    try {
      if (msg.type === 'PAIR_CHECK' || msg.type === 'CAMPAIGNS') {
        const data = await api('/prospector/ext/campaigns', { method: 'GET' });
        sendResponse({ ok: true, data });
      } else if (msg.type === 'EVALUATE') {
        const data = await api('/prospector/ext/evaluate', {
          method: 'POST',
          body: JSON.stringify(msg.payload),
        });
        sendResponse({ ok: true, data });
      } else if (msg.type === 'CAPTURE') {
        const data = await api('/prospector/ext/targets', {
          method: 'POST',
          body: JSON.stringify(msg.payload),
        });
        sendResponse({ ok: true, data });
      } else if (msg.type === 'MAPS_CAPTURE') {
        const data = await api('/prospector/ext/maps', {
          method: 'POST',
          body: JSON.stringify(msg.payload),
        });
        sendResponse({ ok: true, data });
      } else {
        sendResponse({ ok: false, error: 'Mensagem desconhecida.' });
      }
    } catch (err) {
      sendResponse({ ok: false, error: err && err.message ? err.message : String(err) });
    }
  })();
  return true; // resposta assíncrona
});
