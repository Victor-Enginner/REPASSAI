// Captura ASSISTIDA: o usuário abre um perfil e clica para avaliar/capturar.
// Não há automação de envio — a DM é gerada e copiada para o usuário enviar manualmente.
(function () {
  if (window.__crmProspectorPanel) return;
  window.__crmProspectorPanel = true;

  let lastResult = null;

  const panel = document.createElement('div');
  panel.style.cssText =
    'position:fixed;right:16px;bottom:16px;z-index:2147483647;width:280px;font-family:system-ui,sans-serif;' +
    'background:#fff;border:1px solid #e5e7eb;border-radius:12px;box-shadow:0 8px 24px rgba(0,0,0,.18);padding:12px;color:#16181d';
  panel.innerHTML =
    '<div style="font-weight:700;margin-bottom:8px">CRM Prospector</div>' +
    '<select id="crm-campaign" style="width:100%;padding:7px;border:1px solid #e5e7eb;border-radius:8px;font-size:12px;margin-bottom:8px"></select>' +
    '<button id="crm-eval" style="width:100%;padding:8px;border:0;border-radius:8px;background:#14151b;color:#fff;cursor:pointer">Avaliar perfil</button>' +
    '<button id="crm-capture" style="width:100%;margin-top:6px;padding:8px;border:1px solid #14151b;border-radius:8px;background:#fff;color:#14151b;cursor:pointer">Capturar no CRM</button>' +
    '<button id="crm-copy" style="width:100%;margin-top:6px;padding:8px;border:0;border-radius:8px;background:#eef0f4;cursor:pointer;display:none">Copiar DM</button>' +
    '<div id="crm-out" style="margin-top:8px;font-size:13px;color:#374151;white-space:pre-wrap"></div>';
  document.body.appendChild(panel);

  const campaignEl = panel.querySelector('#crm-campaign');
  const out = panel.querySelector('#crm-out');
  const copyBtn = panel.querySelector('#crm-copy');

  function setOut(text) {
    out.textContent = text;
  }

  // Carrega as campanhas da org pareada.
  chrome.runtime.sendMessage({ type: 'CAMPAIGNS' }, (res) => {
    if (res && res.ok && Array.isArray(res.data) && res.data.length > 0) {
      campaignEl.innerHTML = res.data
        .map((c) => `<option value="${c.id}">${c.name}</option>`)
        .join('');
    } else {
      campaignEl.innerHTML = '<option value="">Crie uma campanha no CRM</option>';
    }
  });

  function parseCount(raw) {
    const m = String(raw || '').trim().match(/^([\d.,]+)\s*([KkMm])?/);
    if (!m) return 0;
    let num = parseFloat(m[1].replace(/,/g, ''));
    if (isNaN(num)) num = parseFloat(m[1].replace(/\./g, ''));
    if (isNaN(num)) return 0;
    const suffix = (m[2] || '').toLowerCase();
    if (suffix === 'k') num *= 1000;
    if (suffix === 'm') num *= 1000000;
    return Math.round(num);
  }

  function meta(prop) {
    const el =
      document.querySelector(`meta[property="${prop}"]`) ||
      document.querySelector(`meta[name="${prop}"]`);
    return el ? el.getAttribute('content') || '' : '';
  }

  // Lê o perfil aberto a partir das meta tags públicas (mais estável que seletores de DOM).
  // Multiplataforma: Instagram e LinkedIn têm formatos diferentes de og:title/description.
  function scrapeProfile() {
    const title = meta('og:title');
    const desc = meta('og:description');
    const isLinkedIn = location.hostname.includes('linkedin.com');

    if (isLinkedIn) {
      // URL: /in/<slug>; og:title: "Nome - Cargo - Empresa | LinkedIn".
      const slug = (location.pathname.match(/\/in\/([^/]+)/) || [])[1] || 'desconhecido';
      const name = title.split(/[-|]/)[0].trim() || slug;
      const bio = (title.replace(/\s*\|\s*LinkedIn.*$/i, '').trim() || desc).slice(0, 280);
      return { handle: slug, profile: { name, bio, followers: 0, verified: false, source: 'linkedin' } };
    }

    // Instagram.
    const handleMatch = title.match(/\(@([^)]+)\)/) || desc.match(/\(@([^)]+)\)/);
    const handle = (handleMatch ? handleMatch[1] : location.pathname.replace(/\//g, '')) || 'desconhecido';
    const name = title.split('(@')[0].replace(/[•·|].*$/, '').trim();
    const followersMatch = desc.match(/([\d.,KkMm]+)\s*(?:Followers|seguidores)/i);
    const followers = followersMatch ? parseCount(followersMatch[1]) : 0;
    const bioMatch = desc.match(/:\s*["""]?(.+?)["""]?\s*$/);
    const bio = bioMatch ? bioMatch[1].slice(0, 280) : '';
    const verified = !!document.querySelector(
      'svg[aria-label="Verified"], svg[aria-label="Verificada"], svg[aria-label="Verificado"]',
    );
    return { handle, profile: { name, bio, followers, verified, source: 'instagram' } };
  }

  panel.querySelector('#crm-eval').addEventListener('click', () => {
    setOut('Avaliando…');
    copyBtn.style.display = 'none';
    const captured = scrapeProfile();
    chrome.runtime.sendMessage({ type: 'EVALUATE', payload: captured }, (res) => {
      if (res && res.ok) {
        lastResult = { handle: captured.handle, dm: res.data.dm };
        setOut(`@${captured.handle}\nScore: ${res.data.score}\n\n${res.data.dm}`);
        copyBtn.style.display = 'block';
      } else {
        setOut('Erro: ' + ((res && res.error) || 'sem resposta'));
      }
    });
  });

  panel.querySelector('#crm-capture').addEventListener('click', () => {
    const campaignId = campaignEl.value;
    if (!campaignId) {
      setOut('Selecione (ou crie) uma campanha no CRM primeiro.');
      return;
    }
    const captured = scrapeProfile();
    setOut('Capturando…');
    chrome.runtime.sendMessage(
      { type: 'CAPTURE', payload: { campaignId, handles: [captured.handle] } },
      (res) => {
        if (res && res.ok) {
          setOut(res.data.added > 0 ? `@${captured.handle} capturado no CRM.` : `@${captured.handle} já estava na campanha.`);
        } else {
          setOut('Erro: ' + ((res && res.error) || 'sem resposta'));
        }
      },
    );
  });

  // Envio é MANUAL: copia a DM para o usuário colar e enviar por conta própria.
  copyBtn.addEventListener('click', () => {
    if (!lastResult) return;
    navigator.clipboard.writeText(lastResult.dm).then(
      () => setOut(out.textContent + '\n\n✓ DM copiada — envie manualmente.'),
      () => setOut('Não foi possível copiar a DM.'),
    );
  });
})();
