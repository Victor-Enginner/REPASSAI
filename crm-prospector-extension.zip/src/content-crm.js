// Roda no app do CRM: sinaliza que a extensão está instalada para o ProspectorPage.
// Detecção esperada pelo app: atributo `data-crm-prospector` ou handshake PING/PONG.
const CRM_EXT_VERSION = '0.3.0';

try {
  document.documentElement.setAttribute('data-crm-prospector', CRM_EXT_VERSION);
} catch (_err) {
  // documentElement indisponível neste momento — o handshake abaixo cobre o caso.
}

window.addEventListener('message', (event) => {
  if (event.source !== window) return;
  if (event.data && event.data.type === 'CRM_PROSPECTOR_PING') {
    window.postMessage(
      { type: 'CRM_PROSPECTOR_PONG', version: CRM_EXT_VERSION },
      window.location.origin,
    );
  }
});
