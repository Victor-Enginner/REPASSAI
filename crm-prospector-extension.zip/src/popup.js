const tokenEl = document.getElementById('token');
const statusEl = document.getElementById('status');
const pairBox = document.getElementById('pairBox');
const captureBox = document.getElementById('capture');
const listEl = document.getElementById('list');
const capStatus = document.getElementById('capStatus');
const capIntro = document.getElementById('capIntro');

function setStatus(text, ok) {
  statusEl.textContent = text;
  statusEl.className = ok ? 'ok' : 'err';
}
function setCap(text, ok) {
  capStatus.textContent = text;
  capStatus.className = ok ? 'ok' : 'err';
}

// ── Pareamento ──────────────────────────────────────────────────────────────
function showCaptureIfPaired(paired) {
  pairBox.classList.toggle('paired', paired);
  captureBox.style.display = paired ? 'block' : 'none';
  if (paired) void initCapture();
}

chrome.storage.local.get('pairingToken').then(({ pairingToken }) => {
  if (pairingToken) {
    tokenEl.value = pairingToken;
    setStatus('Pareado.', true);
    showCaptureIfPaired(true);
  }
});

document.getElementById('pair').addEventListener('click', async () => {
  const token = tokenEl.value.trim();
  if (!token) {
    setStatus('Cole o código de pareamento.', false);
    return;
  }
  await chrome.storage.local.set({ pairingToken: token });
  setStatus('Verificando…', true);
  chrome.runtime.sendMessage({ type: 'PAIR_CHECK' }, (res) => {
    if (res && res.ok) {
      setStatus('Pareado com sucesso!', true);
      showCaptureIfPaired(true);
    } else {
      setStatus('Falha: ' + ((res && res.error) || 'sem resposta'), false);
    }
  });
});

// ── Captura no Google Maps (via aba ativa) ───────────────────────────────────
async function activeTab() {
  const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
  return tab || null;
}
function isMaps(url) {
  return /^https:\/\/www\.google\.com\/maps/.test(url || '');
}

async function initCapture() {
  const tab = await activeTab();
  if (!tab || !isMaps(tab.url)) {
    capIntro.textContent = 'Abra o Google Maps numa aba, pesquise um nicho e volte aqui para capturar.';
    return;
  }
  // Pré-preenche o nome da lista com o termo pesquisado.
  const m = (tab.url || '').match(/\/maps\/search\/([^/@]+)/);
  if (m && !listEl.value) {
    try {
      const q = decodeURIComponent(m[1]).replace(/\+/g, ' ').trim();
      listEl.value = q.charAt(0).toUpperCase() + q.slice(1);
    } catch (_e) {
      // ignora
    }
  }
}

// Função INJETADA na página do Maps (precisa ser autocontida).
function scrapeMaps() {
  const PHONE_RE = /\(?\d{2}\)?[\s.-]?\d{4,5}[\s.-]?\d{4}/;
  const lines = (el) => (el.innerText || '').split('\n').map((s) => s.trim()).filter(Boolean);
  const items = [];
  const seen = new Set();

  const feed = document.querySelector('div[role="feed"]');
  const anchors = (feed || document).querySelectorAll('a[href*="/maps/place/"]');
  anchors.forEach((a) => {
    const name = (a.getAttribute('aria-label') || '').trim();
    if (!name || seen.has(a.href)) return;
    seen.add(a.href);
    const card = a.closest('div[role="feed"] > div') || a.parentElement;
    const ls = card ? lines(card) : [];
    let rating;
    let category;
    let address;
    let phone;
    ls.forEach((line) => {
      if (rating === undefined) {
        const r = line.match(/^(\d[.,]\d)\s/);
        if (r) rating = parseFloat(r[1].replace(',', '.'));
      }
      if (!phone) {
        const p = line.match(PHONE_RE);
        if (p) phone = p[0];
      }
      if (!category && line.includes('·') && !/^\d/.test(line)) {
        const parts = line.split('·').map((s) => s.trim());
        category = parts[0];
        if (parts[1] && !address) address = parts[1];
      }
      if (!address && /\d/.test(line) && /(rua|av\.?|avenida|r\.|rod\.|alameda|pra[çc]a|travessa)/i.test(line)) {
        address = line;
      }
    });
    const site = card ? card.querySelector('a[href^="http"]:not([href*="google."])') : null;
    items.push({ name, phone, category, address, rating, website: site ? site.href : undefined, mapsUrl: a.href });
  });

  if (/\/maps\/place\//.test(location.pathname)) {
    const h1 = document.querySelector('h1');
    const name = h1 ? h1.textContent.trim() : '';
    if (name && !items.some((i) => i.mapsUrl === location.href)) {
      const pb = document.querySelector('button[data-item-id^="phone:tel:"], a[data-item-id^="phone:tel:"]');
      const phone = pb ? (pb.getAttribute('data-item-id') || '').replace('phone:tel:', '').trim() : undefined;
      const site = document.querySelector('a[data-item-id="authority"]');
      const ab = document.querySelector('button[data-item-id="address"]');
      const address = ab ? (ab.getAttribute('aria-label') || '').replace(/^Endereço:\s*/i, '').trim() : undefined;
      const rEl = document.querySelector('div.F7nice span[aria-hidden="true"]');
      const rating = rEl ? parseFloat(rEl.textContent.replace(',', '.')) : undefined;
      items.push({ name, phone, website: site ? site.href : undefined, address, rating, mapsUrl: location.href });
    }
  }

  return items.map((i) => {
    const o = { name: i.name, mapsUrl: i.mapsUrl };
    if (i.phone) o.phone = i.phone;
    if (i.website) o.website = i.website;
    if (i.address) o.address = i.address;
    if (i.category) o.category = i.category;
    if (typeof i.rating === 'number' && !isNaN(i.rating)) o.rating = i.rating;
    return o;
  });
}

async function runCapture() {
  const tab = await activeTab();
  if (!tab || !isMaps(tab.url)) {
    setCap('Você não está numa aba do Google Maps. Abra o Maps, pesquise e tente de novo.', false);
    return;
  }
  const list = (listEl.value || '').trim();
  if (!list) {
    setCap('Dê um nome à lista primeiro.', false);
    return;
  }
  setCap('Lendo a página…', true);
  try {
    const results = await chrome.scripting.executeScript({ target: { tabId: tab.id }, func: scrapeMaps });
    const items = (results && results[0] && results[0].result) || [];
    if (items.length === 0) {
      setCap('Nada encontrado. Role a lista de resultados no Maps e tente de novo.', false);
      return;
    }
    chrome.runtime.sendMessage({ type: 'MAPS_CAPTURE', payload: { list, items } }, (res) => {
      if (res && res.ok) {
        const withPhone = items.filter((i) => i.phone).length;
        setCap('✓ ' + items.length + ' salvos na lista "' + list + '".\n' + withPhone + ' com telefone (prontos p/ disparo).', true);
      } else {
        setCap('Erro: ' + ((res && res.error) || 'sem resposta. Repareou a extensão?'), false);
      }
    });
  } catch (err) {
    setCap('Erro ao ler a página: ' + (err && err.message ? err.message : String(err)), false);
  }
}

document.getElementById('cap-search').addEventListener('click', () => void runCapture());
document.getElementById('cap-place').addEventListener('click', () => void runCapture());
