// Prospecção no Google Maps (captura assistida). O usuário pesquisa um nicho, a extensão
// lê os resultados visíveis (nome, categoria, endereço, telefone, site, avaliação) e salva
// numa LISTA no CRM para disparo/prospecção posterior. Nada é enviado automaticamente.
(function () {
  if (window.__crmMapsPanel) return;
  window.__crmMapsPanel = true;

  const PHONE_RE = /\(?\d{2}\)?[\s.-]?\d{4,5}[\s.-]?\d{4}/;

  // ── Painel flutuante ──────────────────────────────────────────────────────
  const panel = document.createElement('div');
  panel.style.cssText =
    'position:fixed;right:18px;bottom:18px;z-index:2147483647;width:300px;font-family:system-ui,-apple-system,sans-serif;' +
    'background:#fff;border:1px solid #e5e7eb;border-radius:14px;box-shadow:0 12px 34px rgba(0,0,0,.22);padding:14px;color:#16181d';
  panel.innerHTML =
    '<div style="display:flex;align-items:center;gap:8px;margin-bottom:10px">' +
    '<div style="width:22px;height:22px;border-radius:6px;background:#111827;color:#fff;display:grid;place-items:center;font-size:12px;font-weight:800">◎</div>' +
    '<div style="font-weight:700;font-size:13.5px;flex:1">CRM Prospector · Maps</div>' +
    '<button id="crm-min" title="Minimizar" style="border:0;background:#f3f4f6;border-radius:6px;width:22px;height:22px;cursor:pointer;color:#6b7280">–</button>' +
    '</div>' +
    '<div id="crm-min-body">' +
    '<label style="font-size:11px;font-weight:600;color:#6b7280;display:block;margin-bottom:4px">Nome da lista</label>' +
    '<input id="crm-list" placeholder="ex.: Restaurantes SP" style="width:100%;padding:8px 10px;border:1px solid #e5e7eb;border-radius:8px;font-size:13px;margin-bottom:10px;box-sizing:border-box" />' +
    '<button id="crm-scan" style="width:100%;padding:9px;border:0;border-radius:9px;background:#111827;color:#fff;font-size:13px;font-weight:600;cursor:pointer">Capturar resultados da busca</button>' +
    '<button id="crm-place" style="width:100%;margin-top:7px;padding:9px;border:1px solid #111827;border-radius:9px;background:#fff;color:#111827;font-size:13px;font-weight:600;cursor:pointer;display:none">Capturar este lugar</button>' +
    '<div id="crm-out" style="margin-top:10px;font-size:12.5px;color:#374151;line-height:1.45;white-space:pre-wrap"></div>' +
    '</div>';
  document.body.appendChild(panel);

  const listEl = panel.querySelector('#crm-list');
  const out = panel.querySelector('#crm-out');
  const scanBtn = panel.querySelector('#crm-scan');
  const placeBtn = panel.querySelector('#crm-place');
  const minBody = panel.querySelector('#crm-min-body');
  const minBtn = panel.querySelector('#crm-min');

  minBtn.addEventListener('click', () => {
    const hidden = minBody.style.display === 'none';
    minBody.style.display = hidden ? 'block' : 'none';
    minBtn.textContent = hidden ? '–' : '+';
  });

  function setOut(text, color) {
    out.textContent = text;
    out.style.color = color || '#374151';
  }

  // Pré-preenche o nome da lista com o termo pesquisado na URL.
  function queryFromUrl() {
    const m = location.pathname.match(/\/maps\/search\/([^/@]+)/);
    if (!m) return '';
    try {
      return decodeURIComponent(m[1]).replace(/\+/g, ' ').trim();
    } catch {
      return '';
    }
  }
  const q = queryFromUrl();
  if (q) listEl.value = q.charAt(0).toUpperCase() + q.slice(1);

  // ── Extração ──────────────────────────────────────────────────────────────
  function textLines(el) {
    return (el.innerText || '')
      .split('\n')
      .map((l) => l.trim())
      .filter(Boolean);
  }

  function pickWebsite(card) {
    const a = card.querySelector('a[href^="http"]:not([href*="google."]):not([href*="gstatic"])');
    return a ? a.href : undefined;
  }

  // Um card de resultado da lista → objeto de empresa (best-effort; alguns campos faltam na lista).
  function parseCard(anchor) {
    const card = anchor.closest('div[role="feed"] > div, div[jsaction]') || anchor.parentElement;
    if (!card) return null;
    const name = (anchor.getAttribute('aria-label') || '').trim();
    if (!name) return null;
    const lines = textLines(card);
    let rating;
    let category;
    let address;
    let phone;
    for (const line of lines) {
      if (rating === undefined) {
        const rm = line.match(/^(\d[.,]\d)\s/);
        if (rm) rating = parseFloat(rm[1].replace(',', '.'));
      }
      if (!phone) {
        const pm = line.match(PHONE_RE);
        if (pm) phone = pm[0];
      }
      // Linha "Categoria · Bairro/rua" (contém o separador do Maps).
      if (!category && line.includes('·') && !line.match(/^\d/)) {
        const parts = line.split('·').map((p) => p.trim());
        category = parts[0];
        if (parts[1] && !address) address = parts[1];
      }
      if (!address && /\d/.test(line) && /(rua|av\.?|avenida|r\.|travessa|rod\.|alameda|pra[çc]a)/i.test(line)) {
        address = line;
      }
    }
    return {
      name,
      ...(phone ? { phone } : {}),
      ...(category ? { category } : {}),
      ...(address ? { address } : {}),
      ...(rating !== undefined ? { rating } : {}),
      ...(pickWebsite(card) ? { website: pickWebsite(card) } : {}),
      mapsUrl: anchor.href,
    };
  }

  function scanFeed() {
    const feed = document.querySelector('div[role="feed"]');
    const scope = feed || document;
    const anchors = Array.from(scope.querySelectorAll('a[href*="/maps/place/"]'));
    const byUrl = new Map();
    for (const a of anchors) {
      const item = parseCard(a);
      if (item && item.name && !byUrl.has(item.mapsUrl)) byUrl.set(item.mapsUrl, item);
    }
    return Array.from(byUrl.values());
  }

  // Página de um lugar (/maps/place/...) → dados ricos (telefone/site/endereço confiáveis).
  function parsePlace() {
    const h1 = document.querySelector('h1');
    const name = h1 ? h1.textContent.trim() : '';
    if (!name) return null;
    const q = (sel) => document.querySelector(sel);
    const phoneBtn = q('button[data-item-id^="phone:tel:"], a[data-item-id^="phone:tel:"]');
    let phone;
    if (phoneBtn) {
      const id = phoneBtn.getAttribute('data-item-id') || '';
      phone = id.replace('phone:tel:', '').trim() || (phoneBtn.getAttribute('aria-label') || '').replace(/[^\d+()\-\s]/g, '').trim();
    }
    const site = q('a[data-item-id="authority"]');
    const addrBtn = q('button[data-item-id="address"]');
    const address = addrBtn ? (addrBtn.getAttribute('aria-label') || '').replace(/^Endereço:\s*/i, '').trim() : undefined;
    const ratingEl = q('div.F7nice span[aria-hidden="true"]');
    const rating = ratingEl ? parseFloat(ratingEl.textContent.replace(',', '.')) : undefined;
    const catEl = q('button[jsaction*="category"]');
    return {
      name,
      ...(phone ? { phone } : {}),
      ...(site ? { website: site.href } : {}),
      ...(address ? { address } : {}),
      ...(rating && !isNaN(rating) ? { rating } : {}),
      ...(catEl && catEl.textContent.trim() ? { category: catEl.textContent.trim() } : {}),
      mapsUrl: location.href,
    };
  }

  function send(items) {
    const list = listEl.value.trim();
    if (!list) {
      setOut('Dê um nome à lista primeiro.', '#dc2626');
      return;
    }
    if (items.length === 0) {
      setOut('Nada encontrado para capturar. Role a lista de resultados e tente de novo.', '#dc2626');
      return;
    }
    setOut('Salvando ' + items.length + ' empresa(s)…');
    chrome.runtime.sendMessage({ type: 'MAPS_CAPTURE', payload: { list, items } }, (res) => {
      if (res && res.ok) {
        const withPhone = items.filter((i) => i.phone).length;
        setOut('✓ ' + (res.data?.saved ?? items.length) + ' salvos na lista "' + list + '".\n' + withPhone + ' com telefone (prontos p/ disparo).', '#15803d');
      } else {
        setOut('Erro: ' + ((res && res.error) || 'sem resposta do CRM. Pareou a extensão?'), '#dc2626');
      }
    });
  }

  scanBtn.addEventListener('click', () => send(scanFeed()));
  placeBtn.addEventListener('click', () => {
    const p = parsePlace();
    send(p ? [p] : []);
  });

  // Mostra "Capturar este lugar" só quando um lugar está aberto; atualiza contagem da busca.
  setInterval(() => {
    const onPlace = /\/maps\/place\//.test(location.pathname);
    placeBtn.style.display = onPlace ? 'block' : 'none';
    if (!onPlace && document.querySelector('div[role="feed"]')) {
      const n = document.querySelectorAll('div[role="feed"] a[href*="/maps/place/"]').length;
      scanBtn.textContent = n > 0 ? `Capturar resultados da busca (${n})` : 'Capturar resultados da busca';
    }
  }, 1200);
})();
