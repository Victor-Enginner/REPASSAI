# DESIGN.md — macOS Physics Simulation Template

Origem: registry privado 77lib
Slug: `aura-template-macos-physics-46`

## Objetivo
An interactive macOS-inspired desktop environment template featuring real-time physics, gravity, and item spawning mechanics. Fonte: https://www.aura.build/templates/macos-physics-46

## Direção visual
- Manter a composição original: proporções, ritmo vertical, blocos de
  conteúdo e atmosfera.
- Preservar hierarquia tipográfica, contraste, espaçamento, estados
  visuais e tratamento de imagens.
- Adaptar responsivamente sem descaracterizar o layout.

## Paleta detectada


## Tipografia detectada
- Inter

## Estrutura de seções
- (não detectadas)

## Regras de implementação
- O `index.html` do template é a fonte principal de verdade.
- Não simplificar a identidade visual: manter imagens, gradientes, cards,
  overlays, efeitos e ritmo da copy.
- Ao converter para React, chegar ao resultado fiel antes de refatorar
  em componentes.
- Trocar apenas textos, links e imagens necessários ao novo negócio.
- Nunca inserir número que o negócio não tenha (avaliação, anos de
  mercado, nº de clientes). Dado não verificado não vai para o site.
