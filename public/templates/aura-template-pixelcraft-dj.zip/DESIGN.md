# DESIGN.md — PixelCraft Professional DJ Services Landing Page Template

Origem: registry privado 77lib
Slug: `aura-template-pixelcraft-dj`

## Objetivo
A high-fidelity, professional DJ and music service template featuring animated performance systems, visual curation, and dark-mode aesthetic. Fonte: https://www.aura.build/templates/pixelcraft-dj

## Direção visual
- Manter a composição original: proporções, ritmo vertical, blocos de
  conteúdo e atmosfera.
- Preservar hierarquia tipográfica, contraste, espaçamento, estados
  visuais e tratamento de imagens.
- Adaptar responsivamente sem descaracterizar o layout.

## Paleta detectada
- #07100b  (19x)
- #09090b  (7x)
- #070708  (4x)
- #050505  (3x)
- #0a0a0c  (2x)
- #047857  (2x)
- rgba(255, 255, 255, 0.015)  (2x)
- rgba(255,255,255,0.12)  (2x)
- rgba(0,0,0,0.8)  (2x)
- rgba(255,255,255,1)  (2x)
- rgba(255,255,255,0.02)  (2x)
- rgba(0,0,0,1)  (2x)
- rgba(255,255,255,0.2)  (2x)
- rgba(0,0,0,0.5)  (2x)
- rgba(255,255,255,0.06)  (2x)
- #000  (1x)

## Tipografia detectada
- Inter
- Anton
- DM Sans

## Estrutura de seções
- Curate audio sets with absolute precision.
- Curated audio, expressive beats.
- Sets with a measurable pulse.
- A clean sequence from booking to stage.
- “The sets completely transformed the energy of the room.”
- Bring your next DJ set into focus.

## Regras de implementação
- O `index.html` do template é a fonte principal de verdade.
- Não simplificar a identidade visual: manter imagens, gradientes, cards,
  overlays, efeitos e ritmo da copy.
- Ao converter para React, chegar ao resultado fiel antes de refatorar
  em componentes.
- Trocar apenas textos, links e imagens necessários ao novo negócio.
- Nunca inserir número que o negócio não tenha (avaliação, anos de
  mercado, nº de clientes). Dado não verificado não vai para o site.
