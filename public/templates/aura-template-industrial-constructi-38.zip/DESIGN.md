# DESIGN.md — Construction  Steel Reinforcement Landing Page Template

Origem: registry privado 77lib
Slug: `aura-template-industrial-constructi-38`

## Objetivo
A high-performance construction template designed for reinforcement specialists, structural engineering firms, and general contractors in the building industry. Fonte: https://www.aura.build/templates/industrial-constructi-38

## Direção visual
- Manter a composição original: proporções, ritmo vertical, blocos de
  conteúdo e atmosfera.
- Preservar hierarquia tipográfica, contraste, espaçamento, estados
  visuais e tratamento de imagens.
- Adaptar responsivamente sem descaracterizar o layout.

## Paleta detectada
- #f59e0b  (6x)
- rgba(245,158,11,0.15)  (6x)
- rgba(9,9,11,0.9)  (6x)
- rgba(245,158,11,0.05)  (3x)
- rgba(245,158,11,0.07)  (3x)
- #fcd34d  (2x)
- rgba(255,255,255,0.4)  (2x)
- #fbbf24  (1x)
- rgba(245,158,11,0.13)  (1x)
- rgba(245,158,11,0.09)  (1x)
- rgba(120,113,108,0.14)  (1x)
- rgba(245,158,11,0.35)  (1x)
- rgba(9,9,11,0.85)  (1x)
- rgba(255,255,255,0.5)  (1x)
- rgba(9,9,11,0.97)  (1x)
- rgba(9,9,11,0.75)  (1x)

## Tipografia detectada
- Inter
- Archivo

## Estrutura de seções
- Betonstahlverlegung, auf die Sie bauen können.
- Bewehrungsarbeiten aus einer Hand
- Weil Ihre Betonage nicht warten kann.
- Ihr Partner im Rohbau
- Von der Anfrage zur Abnahme
- Einblicke in unsere Arbeit
- Von Herford aus in ganz NRW &amp; Niedersachsen
- Häufige Fragen
- Ihr nächstes Projekt braucht eine starke Bewehrung?
- Projekt anfragen

## Regras de implementação
- O `index.html` do template é a fonte principal de verdade.
- Não simplificar a identidade visual: manter imagens, gradientes, cards,
  overlays, efeitos e ritmo da copy.
- Ao converter para React, chegar ao resultado fiel antes de refatorar
  em componentes.
- Trocar apenas textos, links e imagens necessários ao novo negócio.
- Nunca inserir número que o negócio não tenha (avaliação, anos de
  mercado, nº de clientes). Dado não verificado não vai para o site.
