# DESIGN.md — Automotive Detailing and Wrapping Landing Page Template

Origem: registry privado 77lib
Slug: `aura-template-automotive-wrap-33`

## Objetivo
A high-end, premium reusable template designed for car wrapping studios, detailing services, and automotive protection businesses. Fonte: https://www.aura.build/templates/automotive-wrap-33

## Direção visual
- Manter a composição original: proporções, ritmo vertical, blocos de
  conteúdo e atmosfera.
- Preservar hierarquia tipográfica, contraste, espaçamento, estados
  visuais e tratamento de imagens.
- Adaptar responsivamente sem descaracterizar o layout.

## Paleta detectada
- #bbcf1d  (132x)
- #0a0a0a  (32x)
- #222222  (6x)
- #a0a0a0  (6x)
- rgba(187,207,29,0.15)  (6x)
- rgba(187,207,29,0.08)  (6x)
- #d4e34a  (3x)
- #8cb314  (3x)
- #507e0c  (3x)
- #1f3603  (3x)
- rgba(187, 207, 29, 0.3)  (3x)
- rgba(255,255,255,0.05)  (3x)
- rgba(187,207,29,0.3)  (3x)
- rgba(187,207,29,0.25)  (3x)
- rgba(187, 207, 29, 0.6)  (2x)
- rgba(255,255,255,0.03)  (2x)

## Tipografia detectada
- Inter
- Orbitron

## Estrutura de seções
- Dokonalost v každém detailu
- Co pro vás umíme udělat
- Proč si vybrat právě nás
- Neviditelný štít pro váš vůz
- Proces k dokonalosti
- Naše realizace
- Nekompromisní hodnocení
- Změňte svůj vůz k nepoznání.

## Regras de implementação
- O `index.html` do template é a fonte principal de verdade.
- Não simplificar a identidade visual: manter imagens, gradientes, cards,
  overlays, efeitos e ritmo da copy.
- Ao converter para React, chegar ao resultado fiel antes de refatorar
  em componentes.
- Trocar apenas textos, links e imagens necessários ao novo negócio.
- Nunca inserir número que o negócio não tenha (avaliação, anos de
  mercado, nº de clientes). Dado não verificado não vai para o site.
