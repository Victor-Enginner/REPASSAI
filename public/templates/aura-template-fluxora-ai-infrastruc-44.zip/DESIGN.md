# DESIGN.md — Fluxora AI Infrastructure Landing Page Template

Origem: registry privado 77lib
Slug: `aura-template-fluxora-ai-infrastruc-44`

## Objetivo
A sophisticated AI-focused landing page template designed for technical SaaS products, featuring dark aesthetics, bento grids, and animated data visualizations. Fonte: https://www.aura.build/templates/fluxora-ai-infrastruc-44

## Direção visual
- Manter a composição original: proporções, ritmo vertical, blocos de
  conteúdo e atmosfera.
- Preservar hierarquia tipográfica, contraste, espaçamento, estados
  visuais e tratamento de imagens.
- Adaptar responsivamente sem descaracterizar o layout.

## Paleta detectada
- rgba(255,255,255,0.0)  (28x)
- rgba(255,255,255,0.05)  (14x)
- #3b82f6  (7x)
- rgba(255,255,255,1)  (5x)
- #fff  (3x)
- rgba(59,130,246,0.25)  (3x)
- #9ca3af  (2x)
- rgba(255, 255, 255, 0.0)  (2x)
- rgba(255,255,255,0)  (2x)
- rgb(255, 255, 255)  (2x)
- rgba(255,255,255,0.95)  (2x)
- rgba(59,130,246,0.10)  (2x)
- #d1d5db  (1x)
- rgba(255, 255, 255, 0.2)  (1x)
- rgb(96, 165, 250)  (1x)
- rgba(255,255,255,0.4)  (1x)

## Tipografia detectada
- Inter

## Estrutura de seções
- Powering the next wave of AI‑driven products
- What our customers say
- ACR Candle Pro — smarter entries, cleaner signals.
- The problem.
- Auden 2.0 Trading Mentorship

## Regras de implementação
- O `index.html` do template é a fonte principal de verdade.
- Não simplificar a identidade visual: manter imagens, gradientes, cards,
  overlays, efeitos e ritmo da copy.
- Ao converter para React, chegar ao resultado fiel antes de refatorar
  em componentes.
- Trocar apenas textos, links e imagens necessários ao novo negócio.
- Nunca inserir número que o negócio não tenha (avaliação, anos de
  mercado, nº de clientes). Dado não verificado não vai para o site.
