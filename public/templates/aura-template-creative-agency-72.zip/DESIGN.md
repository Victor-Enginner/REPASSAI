# DESIGN.md — Creative Studio  Digital Agency Template

Origem: registry privado 77lib
Slug: `aura-template-creative-agency-72`

## Objetivo
A high-impact, brand-forward creative agency template designed to transform ideas into cinematic digital experiences with advanced animations. Fonte: https://www.aura.build/templates/creative-agency-72

## Direção visual
- Manter a composição original: proporções, ritmo vertical, blocos de
  conteúdo e atmosfera.
- Preservar hierarquia tipográfica, contraste, espaçamento, estados
  visuais e tratamento de imagens.
- Adaptar responsivamente sem descaracterizar o layout.

## Paleta detectada
- #e2e1d3  (30x)
- #111111  (14x)
- #121212  (9x)
- #c4c4c4  (7x)
- rgba(0,0,0,0.3)  (7x)
- #0a0a0a  (5x)
- #ff1a1a  (3x)
- rgba(0,0,0,0.6)  (3x)
- #ff0a2f  (1x)
- #0d1210  (1x)
- #ebebeb  (1x)
- rgba(255,26,26,0.5)  (1x)
- rgba(255,26,26,0.2)  (1x)

## Tipografia detectada
- Anton
- Inter
- Caveat

## Estrutura de seções
- WE TRANSFORM IDEAS INTO
- Selected Works
- "412.DIGITAL REDEFINED OUR ONLINE PRESENCE. THEIR APPROACH TO MOTION AND TYPOGRAPHY CREATE
- 412.DIGITAL

## Regras de implementação
- O `index.html` do template é a fonte principal de verdade.
- Não simplificar a identidade visual: manter imagens, gradientes, cards,
  overlays, efeitos e ritmo da copy.
- Ao converter para React, chegar ao resultado fiel antes de refatorar
  em componentes.
- Trocar apenas textos, links e imagens necessários ao novo negócio.
- Nunca inserir número que o negócio não tenha (avaliação, anos de
  mercado, nº de clientes). Dado não verificado não vai para o site.
