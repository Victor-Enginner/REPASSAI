# DESIGN.md — Pizza Delivery and Restaurant Website Template

Origem: registry privado 77lib
Slug: `aura-template-neapolitan-pizzeria-28`

## Objetivo
A warm and artisanal website template designed for local pizzerias featuring a full digital menu and integrated cart functionality. Fonte: https://www.aura.build/templates/neapolitan-pizzeria-28

## Direção visual
- Manter a composição original: proporções, ritmo vertical, blocos de
  conteúdo e atmosfera.
- Preservar hierarquia tipográfica, contraste, espaçamento, estados
  visuais e tratamento de imagens.
- Adaptar responsivamente sem descaracterizar o layout.

## Paleta detectada
- #e23f2e  (255x)
- #2a1a0f  (178x)
- #c4b08a  (141x)
- #f2e6ce  (93x)
- #e6d5b0  (65x)
- #5a3e28  (40x)
- #9b8a72  (33x)
- #b82a1f  (10x)
- #1a1009  (2x)
- rgba(42, 26, 15, 0.1)  (1x)
- rgba(226, 63, 46, 0.4)  (1x)

## Tipografia detectada
- Lilita One
- DM Sans

## Estrutura de seções
- micsas.ff
- Nascuts a Matadepera, fets per compartir.
- Què diuen els nostres veïns
- Les nostres pizzes
- De Matadepera, a la teva taula.
- Dades de lliurament
- Forma de pagament
- Confirmació
- Gràcies!

## Regras de implementação
- O `index.html` do template é a fonte principal de verdade.
- Não simplificar a identidade visual: manter imagens, gradientes, cards,
  overlays, efeitos e ritmo da copy.
- Ao converter para React, chegar ao resultado fiel antes de refatorar
  em componentes.
- Trocar apenas textos, links e imagens necessários ao novo negócio.
- Nunca inserir número que o negócio não tenha (avaliação, anos de
  mercado, nº de clientes). Dado não verificado não vai para o site.
