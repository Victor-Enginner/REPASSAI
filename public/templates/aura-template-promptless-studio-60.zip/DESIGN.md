# DESIGN.md — Promptless Studio Marketing Agency Template

Origem: registry privado 77lib
Slug: `aura-template-promptless-studio-60`

## Objetivo
A high-end, dark-themed agency landing page template focused on trust-based marketing, video content strategy, and AI-driven creative automation. Fonte: https://www.aura.build/templates/promptless-studio-60

## Direção visual
- Manter a composição original: proporções, ritmo vertical, blocos de
  conteúdo e atmosfera.
- Preservar hierarquia tipográfica, contraste, espaçamento, estados
  visuais e tratamento de imagens.
- Adaptar responsivamente sem descaracterizar o layout.

## Paleta detectada
- #ffbd76  (83x)
- #fff6e9  (69x)
- #0a171d  (30x)
- rgba(255,246,233,0.08)  (10x)
- rgba(255,246,233,0.1)  (10x)
- #b85c3a  (8x)
- rgba(10,23,29,0.08)  (6x)
- rgba(255,246,233,0.02)  (6x)
- rgba(255,246,233,0.12)  (5x)
- #f4e9d2  (3x)
- rgba(255,246,233,0.15)  (3x)
- rgba(255,189,118,0.35)  (3x)
- rgba(255,189,118,0.07)  (2x)
- rgba(255,246,233,1)  (2x)
- rgba(255,189,118,0.12)  (2x)
- rgba(10,23,29,0.7)  (1x)

## Tipografia detectada
- Inter
- Caveat

## Estrutura de seções
- Lidi nekupují od těch, kdo tlačí.Kupují od těch, kterým věří.
- Pozornost se dá koupit. Důvěra ne.
- Točíte dobrý obsah. A stejně to neprodává.
- Věříme v pravý opak.
- Jeden systém vás přitáhne. Druhý vás rozšíří.
- Pozornost neumíme věštit. Umíme ji číst.
- Obsah, který se nedá odscrollovat.
- Nejsme pro každého. A je to tak dobře.
- Tři kroky a systém běží za vás.
- Vaše značka si zaslouží růst, aniž by musela tlačit.

## Regras de implementação
- O `index.html` do template é a fonte principal de verdade.
- Não simplificar a identidade visual: manter imagens, gradientes, cards,
  overlays, efeitos e ritmo da copy.
- Ao converter para React, chegar ao resultado fiel antes de refatorar
  em componentes.
- Trocar apenas textos, links e imagens necessários ao novo negócio.
- Nunca inserir número que o negócio não tenha (avaliação, anos de
  mercado, nº de clientes). Dado não verificado não vai para o site.
