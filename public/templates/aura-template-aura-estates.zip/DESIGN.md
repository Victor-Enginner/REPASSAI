# DESIGN.md — Aura Estates Real Estate Template

Origem: registry privado 77lib
Slug: `aura-template-aura-estates`

## Objetivo
A sophisticated luxury real estate template designed for high-end property listings, featuring cinematic animations and a premium aesthetic for exclusive developments. Fonte: https://www.aura.build/templates/aura-estates

## Direção visual
- Manter a composição original: proporções, ritmo vertical, blocos de
  conteúdo e atmosfera.
- Preservar hierarquia tipográfica, contraste, espaçamento, estados
  visuais e tratamento de imagens.
- Adaptar responsivamente sem descaracterizar o layout.

## Paleta detectada
- #f7f5f0  (7x)
- #e6a756  (6x)
- #1a1a1a  (1x)
- #fff  (1x)
- #f2f0ea  (1x)

## Tipografia detectada
- Inter
- DM Serif Display
- DM Sans

## Estrutura de seções
- Exclusive spaces for elevated living today
- Discover environments without boundaries—
- Where visionary design meets enduring elegance.
- Navigating your real estate journey.
- Curated Collection of Excellence.
- Respected by industry leaders, cherished by homeowners.
- Let's discuss your next elevated space.

## Regras de implementação
- O `index.html` do template é a fonte principal de verdade.
- Não simplificar a identidade visual: manter imagens, gradientes, cards,
  overlays, efeitos e ritmo da copy.
- Ao converter para React, chegar ao resultado fiel antes de refatorar
  em componentes.
- Trocar apenas textos, links e imagens necessários ao novo negócio.
- Nunca inserir número que o negócio não tenha (avaliação, anos de
  mercado, nº de clientes). Dado não verificado não vai para o site.
