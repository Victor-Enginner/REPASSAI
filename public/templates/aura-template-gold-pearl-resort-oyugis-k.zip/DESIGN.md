# DESIGN.md — Luxury Resort  Spa Landing Page Template

Origem: registry privado 77lib
Slug: `aura-template-gold-pearl-resort-oyugis-k`

## Objetivo
A premium hotel and hospitality template designed for luxury resorts, featuring room booking modules, dining galleries, and elegant service sections. Fonte: https://www.aura.build/templates/gold-pearl-resort-oyugis-k

## Direção visual
- Manter a composição original: proporções, ritmo vertical, blocos de
  conteúdo e atmosfera.
- Preservar hierarquia tipográfica, contraste, espaçamento, estados
  visuais e tratamento de imagens.
- Adaptar responsivamente sem descaracterizar o layout.

## Paleta detectada


## Tipografia detectada
- Playfair Display
- Inter

## Estrutura de seções
- Experience Luxury Beyond Expectations
- A Legacy of Unmatched Luxury &amp; Refined Elegance
- Sanctuaries of Unrivalled Comfort
- Every Comfort, Every Desire
- A Journey Through Flavour
- The Gallery
- Curated Experiences
- We're Here to Serve You

## Regras de implementação
- O `index.html` do template é a fonte principal de verdade.
- Não simplificar a identidade visual: manter imagens, gradientes, cards,
  overlays, efeitos e ritmo da copy.
- Ao converter para React, chegar ao resultado fiel antes de refatorar
  em componentes.
- Trocar apenas textos, links e imagens necessários ao novo negócio.
- Nunca inserir número que o negócio não tenha (avaliação, anos de
  mercado, nº de clientes). Dado não verificado não vai para o site.
