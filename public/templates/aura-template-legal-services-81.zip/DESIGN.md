# DESIGN.md — Legal Litigation Support Template

Origem: registry privado 77lib
Slug: `aura-template-legal-services-81`

## Objetivo
A high-performance legal services template designed for law firms needing sophisticated litigation staffing and case management solutions. Fonte: https://www.aura.build/templates/legal-services-81

## Direção visual
- Manter a composição original: proporções, ritmo vertical, blocos de
  conteúdo e atmosfera.
- Preservar hierarquia tipográfica, contraste, espaçamento, estados
  visuais e tratamento de imagens.
- Adaptar responsivamente sem descaracterizar o layout.

## Paleta detectada
- #c0ee3c  (35x)
- #a3d12a  (2x)

## Tipografia detectada
- Space Grotesk
- Syne

## Estrutura de seções
- Paralegal Support Built for Modern Legal Workflows.
- Staffing Solutions That Move With Your Practice.
- Areas of Paralegal Support.
- Built Around Workflow Alignment.
- Why Firms Prioritize Integrated Paralegal Support.
- Designed for Modern Legal Teams.
- Strengthen Your Legal Staffing Infrastructure.

## Regras de implementação
- O `index.html` do template é a fonte principal de verdade.
- Não simplificar a identidade visual: manter imagens, gradientes, cards,
  overlays, efeitos e ritmo da copy.
- Ao converter para React, chegar ao resultado fiel antes de refatorar
  em componentes.
- Trocar apenas textos, links e imagens necessários ao novo negócio.
- Nunca inserir número que o negócio não tenha (avaliação, anos de
  mercado, nº de clientes). Dado não verificado não vai para o site.
