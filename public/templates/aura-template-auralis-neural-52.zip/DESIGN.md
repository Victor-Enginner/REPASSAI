# DESIGN.md — Auralis Neural Audio Synthesis Template

Origem: registry privado 77lib
Slug: `aura-template-auralis-neural-52`

## Objetivo
A high-fidelity audio engineering template designed for sound architects, featuring neural synthesis interfaces and spatial audio layouts. Fonte: https://www.aura.build/templates/auralis-neural-52

## Direção visual
- Manter a composição original: proporções, ritmo vertical, blocos de
  conteúdo e atmosfera.
- Preservar hierarquia tipográfica, contraste, espaçamento, estados
  visuais e tratamento de imagens.
- Adaptar responsivamente sem descaracterizar o layout.

## Paleta detectada
- #f5f1e8  (128x)
- #ff7a1a  (45x)
- #0a0a0b  (16x)
- #7df9ff  (12x)
- #0c0c0e  (3x)
- #050506  (1x)
- rgba(255,255,255,0.3)  (1x)
- rgba(125, 249, 255, 0.2)  (1x)
- rgba(255, 122, 26, 0.35)  (1x)

## Tipografia detectada
- Cormorant Garamond
- JetBrains Mono

## Estrutura de seções
- Sound, before silence.
- The Latent Console.
- Architectural Licensing.

## Regras de implementação
- O `index.html` do template é a fonte principal de verdade.
- Não simplificar a identidade visual: manter imagens, gradientes, cards,
  overlays, efeitos e ritmo da copy.
- Ao converter para React, chegar ao resultado fiel antes de refatorar
  em componentes.
- Trocar apenas textos, links e imagens necessários ao novo negócio.
- Nunca inserir número que o negócio não tenha (avaliação, anos de
  mercado, nº de clientes). Dado não verificado não vai para o site.
