# DESIGN.md — Artisanal Coffee  Roastery Landing Page Template

Origem: registry privado 77lib
Slug: `aura-template-artisanal-specialty-91`

## Objetivo
A premium, high-end landing page template for specialty coffee shops and roasteries featuring sophisticated animations and dark mode aesthetics. Fonte: https://www.aura.build/templates/artisanal-specialty-91

## Direção visual
- Manter a composição original: proporções, ritmo vertical, blocos de
  conteúdo e atmosfera.
- Preservar hierarquia tipográfica, contraste, espaçamento, estados
  visuais e tratamento de imagens.
- Adaptar responsivamente sem descaracterizar o layout.

## Paleta detectada
- #e2dcd0  (8x)
- #4f5343  (6x)
- #d3cdc0  (4x)
- #1d1d1c  (3x)
- #4d5240  (3x)
- #b1b2a9  (3x)
- #f3eee2  (2x)
- #e0dcd1  (1x)
- #cebfa9  (1x)
- #31312d  (1x)
- #e8e4d9  (1x)
- #f5f1e8  (1x)
- #ded9cc  (1x)
- #a8a7a2  (1x)
- #e8a598  (1x)
- #d4c19c  (1x)

## Tipografia detectada
- JetBrains Mono
- Manrope
- Playfair Display

## Estrutura de seções
- L'Art de l'Extraction.
- De la ferme à la tasse.

## Regras de implementação
- O `index.html` do template é a fonte principal de verdade.
- Não simplificar a identidade visual: manter imagens, gradientes, cards,
  overlays, efeitos e ritmo da copy.
- Ao converter para React, chegar ao resultado fiel antes de refatorar
  em componentes.
- Trocar apenas textos, links e imagens necessários ao novo negócio.
- Nunca inserir número que o negócio não tenha (avaliação, anos de
  mercado, nº de clientes). Dado não verificado não vai para o site.
