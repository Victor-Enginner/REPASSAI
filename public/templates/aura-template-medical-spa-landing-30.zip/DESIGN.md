# DESIGN.md — Medical Aesthetics  Wellness Landing Page Template

Origem: registry privado 77lib
Slug: `aura-template-medical-spa-landing-30`

## Objetivo
A high-end, brand-forward landing page template designed for medical spas, wellness clinics, and aesthetic practitioners to showcase services and book appointments. Fonte: https://www.aura.build/templates/medical-spa-landing-30

## Direção visual
- Manter a composição original: proporções, ritmo vertical, blocos de
  conteúdo e atmosfera.
- Preservar hierarquia tipográfica, contraste, espaçamento, estados
  visuais e tratamento de imagens.
- Adaptar responsivamente sem descaracterizar o layout.

## Paleta detectada
- #e3c15e  (69x)
- #d1dde8  (9x)
- #2c2c2c  (6x)
- #31353d  (2x)
- #f1f1f1  (1x)
- #d1d5db  (1x)
- #9ca3af  (1x)
- #d4b04c  (1x)
- #fdfcfb  (1x)
- #f8f9fa  (1x)

## Tipografia detectada
- Inter
- Playfair Display

## Estrutura de seções
- VIJAYAWADA Ultimate Med Spa
- Meet Dr. Walid Elkhalili
- Curated Aesthetic Treatments
- Request Appointment
- Cloud La Med Spa

## Regras de implementação
- O `index.html` do template é a fonte principal de verdade.
- Não simplificar a identidade visual: manter imagens, gradientes, cards,
  overlays, efeitos e ritmo da copy.
- Ao converter para React, chegar ao resultado fiel antes de refatorar
  em componentes.
- Trocar apenas textos, links e imagens necessários ao novo negócio.
- Nunca inserir número que o negócio não tenha (avaliação, anos de
  mercado, nº de clientes). Dado não verificado não vai para o site.
