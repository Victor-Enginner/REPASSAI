# DESIGN.md — Personal Trainer Professional Template

Origem: registry privado 77lib
Slug: `aura-template-personal-trainer-97`

## Objetivo
A high-performance landing page template designed for fitness professionals and personal trainers to showcase training methods and results. Fonte: https://www.aura.build/templates/personal-trainer-97

## Direção visual
- Manter a composição original: proporções, ritmo vertical, blocos de
  conteúdo e atmosfera.
- Preservar hierarquia tipográfica, contraste, espaçamento, estados
  visuais e tratamento de imagens.
- Adaptar responsivamente sem descaracterizar o layout.

## Paleta detectada
- #2979ff  (81x)
- #b0b0b0  (32x)
- #050d1a  (30x)
- #f2f2f2  (26x)
- #0b1628  (12x)
- #6b6b6b  (11x)
- #1565c0  (5x)
- #0b3d91  (3x)
- #1a1a1a  (3x)
- #ffffff  (2x)
- rgba(41,121,255,0.1)  (2x)
- rgba(41,121,255,0.2)  (2x)
- rgba(0,0,0,0.8)  (2x)
- rgba(41, 121, 255, 0.35)  (1x)
- rgba(242, 242, 242, 0.1)  (1x)
- rgba(11, 61, 145, 0.15)  (1x)

## Tipografia detectada
- Barlow Condensed
- Inter
- JetBrains Mono

## Estrutura de seções
- LUCAS PRADO
- SEM FRESCURA. SEM ENROLAÇÃO. SÓ RESULTADO.
- VOCÊ NÃO PRECISA DE COMPLICAÇÃO.
- UM MÉTODO SIMPLESQUE FUNCIONA DE VERDADE.
- ALUNOS REAIS.RESULTADOS REAIS.
- VOCÊ ESCOLHEONDE TREINAR.
- PERSONAL TRAINER QUE ENTREGA O QUE PROMETE.
- PERGUNTAS DIRETAS.
- CHEGA DEESPERAR OMOMENTO CERTO.

## Regras de implementação
- O `index.html` do template é a fonte principal de verdade.
- Não simplificar a identidade visual: manter imagens, gradientes, cards,
  overlays, efeitos e ritmo da copy.
- Ao converter para React, chegar ao resultado fiel antes de refatorar
  em componentes.
- Trocar apenas textos, links e imagens necessários ao novo negócio.
- Nunca inserir número que o negócio não tenha (avaliação, anos de
  mercado, nº de clientes). Dado não verificado não vai para o site.
