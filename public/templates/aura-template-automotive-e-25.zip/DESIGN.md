# DESIGN.md — Automotive Parts E-commerce Landing Page Template

Origem: registry privado 77lib
Slug: `aura-template-automotive-e-25`

## Objetivo
A high-performance automotive parts e-commerce template specializing in engine and gearbox components with a bold, technical aesthetic. Fonte: https://www.aura.build/templates/automotive-e-25

## Direção visual
- Manter a composição original: proporções, ritmo vertical, blocos de
  conteúdo e atmosfera.
- Preservar hierarquia tipográfica, contraste, espaçamento, estados
  visuais e tratamento de imagens.
- Adaptar responsivamente sem descaracterizar o layout.

## Paleta detectada
- #c7cdc9  (1x)
- rgba(163,230,53,0.35)  (1x)

## Tipografia detectada
- Archivo
- Inter

## Estrutura de seções
- ENGINE & GEARBOX
- PREMIUM BRANDS
- ENGINE PARTS
- GEARBOX
- THE TRUST
- Catalog

## Regras de implementação
- O `index.html` do template é a fonte principal de verdade.
- Não simplificar a identidade visual: manter imagens, gradientes, cards,
  overlays, efeitos e ritmo da copy.
- Ao converter para React, chegar ao resultado fiel antes de refatorar
  em componentes.
- Trocar apenas textos, links e imagens necessários ao novo negócio.
- Nunca inserir número que o negócio não tenha (avaliação, anos de
  mercado, nº de clientes). Dado não verificado não vai para o site.
