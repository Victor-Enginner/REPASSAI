# DESIGN.md — Minimalist Chess Engine Template

Origem: registry privado 77lib
Slug: `aura-template-built-in-chess-on-aura`

## Objetivo
A clean, interactive Chess game template featuring a built-in AI engine, theme customization, and responsive design. Fonte: https://www.aura.build/templates/built-in-chess-on-aura

## Direção visual
- Manter a composição original: proporções, ritmo vertical, blocos de
  conteúdo e atmosfera.
- Preservar hierarquia tipográfica, contraste, espaçamento, estados
  visuais e tratamento de imagens.
- Adaptar responsivamente sem descaracterizar o layout.

## Paleta detectada
- #0a0a0a  (9x)
- #f0d9b5  (2x)
- #b58863  (2x)
- #ebecd0  (2x)
- #739552  (2x)
- #dee3e6  (2x)
- #8ca2ad  (2x)
- #e4e4e7  (2x)
- #52525b  (2x)
- rgba(18,16,16,0)  (2x)
- rgba(0,0,0,0.25)  (2x)
- rgba(255,0,0,0.06)  (2x)
- rgba(0,255,0,0.02)  (2x)
- rgba(0,0,255,0.06)  (2x)
- rgba(255,255,255,0.8)  (2x)
- #3f3f46  (1x)

## Tipografia detectada
- Inter

## Estrutura de seções
- (não detectadas)

## Regras de implementação
- O `index.html` do template é a fonte principal de verdade.
- Não simplificar a identidade visual: manter imagens, gradientes, cards,
  overlays, efeitos e ritmo da copy.
- Ao converter para React, chegar ao resultado fiel antes de refatorar
  em componentes.
- Trocar apenas textos, links e imagens necessários ao novo negócio.
- Nunca inserir número que o negócio não tenha (avaliação, anos de
  mercado, nº de clientes). Dado não verificado não vai para o site.
