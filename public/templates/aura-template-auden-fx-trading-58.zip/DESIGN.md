# DESIGN.md — Auden FX Trading  Mentorship Template

Origem: registry privado 77lib
Slug: `aura-template-auden-fx-trading-58`

## Objetivo
A high-performance trading indicator and mentorship landing page template designed for financial services and market analysts. Fonte: https://www.aura.build/templates/auden-fx-trading-58

## Direção visual
- Manter a composição original: proporções, ritmo vertical, blocos de
  conteúdo e atmosfera.
- Preservar hierarquia tipográfica, contraste, espaçamento, estados
  visuais e tratamento de imagens.
- Adaptar responsivamente sem descaracterizar o layout.

## Paleta detectada
- #c8c4bc  (110x)
- #8b3a2a  (74x)
- #1a1a1a  (26x)
- rgba(200,196,188,0.2)  (1x)
- rgba(26,26,26,0.8)  (1x)
- rgba(139,58,42,0.3)  (1x)

## Tipografia detectada
- Inter
- JetBrains Mono

## Estrutura de seções
- Trade Dengan Presisi
- Indikator yang membaca struktur candle
- Dua cara akses indikator
- Bimbingan privat hingga konsisten profit
- Kata para trader
- Pertanyaan umum

## Regras de implementação
- O `index.html` do template é a fonte principal de verdade.
- Não simplificar a identidade visual: manter imagens, gradientes, cards,
  overlays, efeitos e ritmo da copy.
- Ao converter para React, chegar ao resultado fiel antes de refatorar
  em componentes.
- Trocar apenas textos, links e imagens necessários ao novo negócio.
- Nunca inserir número que o negócio não tenha (avaliação, anos de
  mercado, nº de clientes). Dado não verificado não vai para o site.
