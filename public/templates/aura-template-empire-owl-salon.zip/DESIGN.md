# DESIGN.md — Beauty Salon  Stylist Landing Page Template

Origem: registry privado 77lib
Slug: `aura-template-empire-owl-salon`

## Objetivo
A sophisticated and warm landing page template designed for independent salons, stylists, and beauty professionals to showcase services and manage bookings. Fonte: https://www.aura.build/templates/empire-owl-salon

## Direção visual
- Manter a composição original: proporções, ritmo vertical, blocos de
  conteúdo e atmosfera.
- Preservar hierarquia tipográfica, contraste, espaçamento, estados
  visuais e tratamento de imagens.
- Adaptar responsivamente sem descaracterizar o layout.

## Paleta detectada
- #fdf7ef  (2x)
- rgba(255,255,255,0.28)  (2x)
- #633b2c  (1x)
- #986a3e  (1x)
- #f7ecdf  (1x)
- #1b120d  (1x)
- rgba(152, 106, 62, 0.1)  (1x)
- rgba(255, 255, 255, 0.3)  (1x)
- rgba(152,106,62,0.45)  (1x)
- rgba(0,0,0,0.15)  (1x)
- rgba(0,0,0,0.65)  (1x)
- rgba(0,0,0,0.68)  (1x)
- rgba(0,0,0,0.08)  (1x)
- rgba(0,0,0,0.3)  (1x)

## Tipografia detectada
- Hedvig Letters Serif
- Inter
- Newsreader

## Estrutura de seções
- Royal hair, wise hands, homestyle care
- We fuse the lion’s royal confidence with the owl’s precision and wisdom to create high-end
- Cuts, color and beauty details with a lived-in finish
- Cuts, color, beauty &amp; finishing
- A small independent salon with a big reputation
- Beauty that feels personal, polished, and never rushed
- What Langford clients say
- Hair guides and beauty inspiration
- Salon questions, answered

## Regras de implementação
- O `index.html` do template é a fonte principal de verdade.
- Não simplificar a identidade visual: manter imagens, gradientes, cards,
  overlays, efeitos e ritmo da copy.
- Ao converter para React, chegar ao resultado fiel antes de refatorar
  em componentes.
- Trocar apenas textos, links e imagens necessários ao novo negócio.
- Nunca inserir número que o negócio não tenha (avaliação, anos de
  mercado, nº de clientes). Dado não verificado não vai para o site.
