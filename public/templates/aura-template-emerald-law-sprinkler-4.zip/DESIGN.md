# DESIGN.md — Emerald Lawn Sprinklers Irrigation Services Template

Origem: registry privado 77lib
Slug: `aura-template-emerald-law-sprinkler-4`

## Objetivo
A professional, conversion-focused landing page template designed for irrigation, landscaping, and seasonal maintenance businesses. Fonte: https://www.aura.build/templates/emerald-law-sprinkler-4

## Direção visual
- Manter a composição original: proporções, ritmo vertical, blocos de
  conteúdo e atmosfera.
- Preservar hierarquia tipográfica, contraste, espaçamento, estados
  visuais e tratamento de imagens.
- Adaptar responsivamente sem descaracterizar o layout.

## Paleta detectada
- #4a8c2a  (75x)
- #111a0c  (63x)
- #f4faf0  (27x)
- #6a7d5e  (16x)
- #9fd96a  (13x)
- rgba(17,26,12,.08)  (13x)
- #6db33f  (12x)
- #7cb95a  (12x)
- #1a2e14  (10x)
- #2e4a24  (10x)
- rgba(74,140,42,.10)  (9x)
- #9ca89a  (8x)
- #131f0e  (8x)
- #0c1208  (7x)
- #1e2e18  (7x)
- rgba(244,250,240,.10)  (7x)

## Tipografia detectada
- Inter
- Sora

## Estrutura de seções
- Keep every lawn green all season long.
- Where most irrigation systems quietly fail your lawn.
- Built for every season and every lawn need.
- What a properly maintained system delivers for your property.
- Four irrigation services that protect your investment all year.
- How Emerald gets your system installed and running right.
- Questions homeowners ask before getting a sprinkler system.
- Ready for a greener lawn?

## Regras de implementação
- O `index.html` do template é a fonte principal de verdade.
- Não simplificar a identidade visual: manter imagens, gradientes, cards,
  overlays, efeitos e ritmo da copy.
- Ao converter para React, chegar ao resultado fiel antes de refatorar
  em componentes.
- Trocar apenas textos, links e imagens necessários ao novo negócio.
- Nunca inserir número que o negócio não tenha (avaliação, anos de
  mercado, nº de clientes). Dado não verificado não vai para o site.
