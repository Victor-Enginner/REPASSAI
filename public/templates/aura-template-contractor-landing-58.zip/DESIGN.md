# DESIGN.md — Handy Prime Contractor Landing Page Template

Origem: registry privado 77lib
Slug: `aura-template-contractor-landing-58`

## Objetivo
A professional home services and general contractor template designed for renovation businesses, featuring service grids, galleries, and trust signals. Fonte: https://www.aura.build/templates/contractor-landing-58

## Direção visual
- Manter a composição original: proporções, ritmo vertical, blocos de
  conteúdo e atmosfera.
- Preservar hierarquia tipográfica, contraste, espaçamento, estados
  visuais e tratamento de imagens.
- Adaptar responsivamente sem descaracterizar o layout.

## Paleta detectada
- #132347  (81x)
- #f5b82e  (69x)
- #f8f9fc  (17x)
- #e0a628  (11x)
- #4285f4  (4x)
- #34a853  (4x)
- #fbbc05  (4x)
- #ea4335  (4x)
- #fff  (1x)
- #0d1832  (1x)
- rgba(19,35,71,.92)  (1x)
- rgba(19,35,71,.18)  (1x)
- rgba(245,184,46,.22)  (1x)
- rgba(59,130,246,.16)  (1x)
- rgba(255,255,255,.16)  (1x)
- rgba(245,184,46,.08)  (1x)

## Tipografia detectada
- Inter
- Bricolage Grotesque

## Estrutura de seções
- Renovations &amp; General Contracting Done Right
- Licensed Duncan general contractor for clean, reliable home improvements.
- Complete Home Renovation &amp; Repair Services
- Bathroom Renovations, Custom Finishing &amp; Home Upgrades
- 5 out of 5 from Duncan homeowners
- Handy Prime in Duncan
- Ready for a cleaner, more professional renovation experience?

## Regras de implementação
- O `index.html` do template é a fonte principal de verdade.
- Não simplificar a identidade visual: manter imagens, gradientes, cards,
  overlays, efeitos e ritmo da copy.
- Ao converter para React, chegar ao resultado fiel antes de refatorar
  em componentes.
- Trocar apenas textos, links e imagens necessários ao novo negócio.
- Nunca inserir número que o negócio não tenha (avaliação, anos de
  mercado, nº de clientes). Dado não verificado não vai para o site.
