# DESIGN.md — Vectorline SaaS Landing Page Template

Origem: registry privado 77lib
Slug: `aura-template-vectorline-saas`

## Objetivo
A sophisticated technical SaaS landing page template designed for complex system mapping, architectural workflows, and enterprise data visualization. Fonte: https://www.aura.build/templates/vectorline-saas

## Direção visual
- Manter a composição original: proporções, ritmo vertical, blocos de
  conteúdo e atmosfera.
- Preservar hierarquia tipográfica, contraste, espaçamento, estados
  visuais e tratamento de imagens.
- Adaptar responsivamente sem descaracterizar o layout.

## Paleta detectada
- rgba(255,255,255,0.08)  (12x)
- rgba(255,255,255,0.1)  (9x)
- rgba(255,255,255,0.12)  (8x)
- rgba(0,0,0,0.9)  (7x)
- rgba(0,0,0,0.35)  (7x)
- rgba(255,255,255,0.05)  (6x)
- rgba(0,0,0,0.95)  (6x)
- rgba(255,255,255,0.035)  (5x)
- rgba(255,255,255,0.16)  (5x)
- rgba(0,0,0,0.8)  (4x)
- rgba(255,255,255,0.025)  (4x)
- rgba(0,0,0,0.85)  (4x)
- rgba(129,140,248,0.15)  (4x)
- rgba(255,255,255,0.045)  (3x)
- rgba(255,255,255,0.09)  (3x)
- rgba(24,24,27,0.92)  (3x)

## Tipografia detectada
- Gloock
- Manrope

## Estrutura de seções
- Map ideas as a measured system.
- Core Architecture Mapping
- A workspace with measurable intent.
- Five candidate visuals indexed for the board.
- From workshop noise to structured output.
- Push structural changes directly to production.

## Regras de implementação
- O `index.html` do template é a fonte principal de verdade.
- Não simplificar a identidade visual: manter imagens, gradientes, cards,
  overlays, efeitos e ritmo da copy.
- Ao converter para React, chegar ao resultado fiel antes de refatorar
  em componentes.
- Trocar apenas textos, links e imagens necessários ao novo negócio.
- Nunca inserir número que o negócio não tenha (avaliação, anos de
  mercado, nº de clientes). Dado não verificado não vai para o site.
