# DESIGN.md — Niteco Enterprise Agency Landing Page Template

Origem: registry privado 77lib
Slug: `aura-template-enterprise-digital-6`

## Objetivo
A high-end, dark-themed agency template designed for digital services, e-commerce solutions, and enterprise-level marketing brands. Fonte: https://www.aura.build/templates/enterprise-digital-6

## Direção visual
- Manter a composição original: proporções, ritmo vertical, blocos de
  conteúdo e atmosfera.
- Preservar hierarquia tipográfica, contraste, espaçamento, estados
  visuais e tratamento de imagens.
- Adaptar responsivamente sem descaracterizar o layout.

## Paleta detectada
- #f9d022  (87x)
- #848e9c  (32x)
- #141618  (28x)
- #17191c  (17x)
- #1c1e21  (2x)
- #ffffff  (1x)
- #333  (1x)
- #1f6520  (1x)
- #d31245  (1x)
- #52364c  (1x)
- #0b1c2c  (1x)
- #7d1c21  (1x)
- rgba(230, 232, 236, 0.1)  (1x)

## Tipografia detectada
- Plus Jakarta Sans

## Estrutura de seções
- Where globaldelivery meetsdigital excellence.
- Digital mastery across all fronts.
- The latest
- Our clients
- Niteco Charity Foundation
- Our offices around the world
- Ready to transformyour digital presence?

## Regras de implementação
- O `index.html` do template é a fonte principal de verdade.
- Não simplificar a identidade visual: manter imagens, gradientes, cards,
  overlays, efeitos e ritmo da copy.
- Ao converter para React, chegar ao resultado fiel antes de refatorar
  em componentes.
- Trocar apenas textos, links e imagens necessários ao novo negócio.
- Nunca inserir número que o negócio não tenha (avaliação, anos de
  mercado, nº de clientes). Dado não verificado não vai para o site.
