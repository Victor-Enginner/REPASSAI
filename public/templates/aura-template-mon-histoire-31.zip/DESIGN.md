# DESIGN.md — Sacha D'Houwer - Système nerveux équin  entreprenariat

Origem: registry privado 77lib
Slug: `aura-template-mon-histoire-31`

## Objetivo
A sophisticated, brand-focused storytelling template designed for professionals in equine therapy, coaching, and nature-based services. Fonte: https://www.aura.build/templates/mon-histoire-31

## Direção visual
- Manter a composição original: proporções, ritmo vertical, blocos de
  conteúdo e atmosfera.
- Preservar hierarquia tipográfica, contraste, espaçamento, estados
  visuais e tratamento de imagens.
- Adaptar responsivamente sem descaracterizar o layout.

## Paleta detectada
- #8da081  (2x)
- rgba(250, 246, 239, .82)  (2x)
- #faf6ef  (1x)
- #f2ebdf  (1x)
- #2b3a2c  (1x)
- #4a5a48  (1x)
- #c5cfbc  (1x)
- #c06b45  (1x)
- #a8552f  (1x)
- #cc9a5b  (1x)
- #ded4c4  (1x)
- #b9c4ac  (1x)
- #6e8064  (1x)
- rgba(43, 58, 44, .35)  (1x)
- rgba(168, 85, 47, .6)  (1x)
- rgba(168, 85, 47, .65)  (1x)

## Tipografia detectada
- Fraunces
- Hanken Grotesk

## Estrutura de seções
- Le stress de ton cheval, ce n'est pas un défaut. C'est un signal.
- Je transmets deux choses. Elles se ressemblent plus qu'on ne croit.
- Enseignante de métier. Cavalière de toujours.
- On commence par le plus simple ?

## Regras de implementação
- O `index.html` do template é a fonte principal de verdade.
- Não simplificar a identidade visual: manter imagens, gradientes, cards,
  overlays, efeitos e ritmo da copy.
- Ao converter para React, chegar ao resultado fiel antes de refatorar
  em componentes.
- Trocar apenas textos, links e imagens necessários ao novo negócio.
- Nunca inserir número que o negócio não tenha (avaliação, anos de
  mercado, nº de clientes). Dado não verificado não vai para o site.
