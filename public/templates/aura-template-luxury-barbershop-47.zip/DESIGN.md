# DESIGN.md — Luxury Barbershop Landing Page Template

Origem: registry privado 77lib
Slug: `aura-template-luxury-barbershop-47`

## Objetivo
A premium, dark-themed service template designed for high-end barbershops and male grooming businesses looking to project exclusivity and sophistication. Fonte: https://www.aura.build/templates/luxury-barbershop-47

## Direção visual
- Manter a composição original: proporções, ritmo vertical, blocos de
  conteúdo e atmosfera.
- Preservar hierarquia tipográfica, contraste, espaçamento, estados
  visuais e tratamento de imagens.
- Adaptar responsivamente sem descaracterizar o layout.

## Paleta detectada
- #c8a65a  (89x)
- #0b0b0b  (25x)
- #1a1a1a  (22x)
- #2f2f2f  (21x)
- #111111  (7x)
- rgba(200,166,90,0.1)  (4x)
- rgba(11, 11, 11, 1)  (2x)
- #151310  (1x)
- #0a0a0a  (1x)
- #25d366  (1x)
- rgba(11, 11, 11, 0.6)  (1x)
- rgba(200,166,90,0.05)  (1x)
- rgba(200,166,90,0.3)  (1x)
- rgba(200,166,90,0.2)  (1x)
- rgba(11, 11, 11, 0.8)  (1x)
- rgba(37,211,102,0.3)  (1x)

## Tipografia detectada
- Montserrat
- Playfair Display

## Estrutura de seções
- Más que un corte.Una experiencia de distinción.
- Tu imagen abre puertas.
- Donde la barbería se convierte en un ritual.
- Elige tu experiencia
- La Experiencia ST. JOCP
- La voz de nuestros clientes
- Primera Visita Exclusiva
- Preguntas Frecuentes
- Tu imagen es una inversión.

## Regras de implementação
- O `index.html` do template é a fonte principal de verdade.
- Não simplificar a identidade visual: manter imagens, gradientes, cards,
  overlays, efeitos e ritmo da copy.
- Ao converter para React, chegar ao resultado fiel antes de refatorar
  em componentes.
- Trocar apenas textos, links e imagens necessários ao novo negócio.
- Nunca inserir número que o negócio não tenha (avaliação, anos de
  mercado, nº de clientes). Dado não verificado não vai para o site.
