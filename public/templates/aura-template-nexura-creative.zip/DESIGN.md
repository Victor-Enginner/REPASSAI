# DESIGN.md — Nexura Creative Agency Landing Page Template

Origem: registry privado 77lib
Slug: `aura-template-nexura-creative`

## Objetivo
A high-performance landing page template designed for ad creative agencies and marketing service providers looking to showcase portfolio work and scale client acquisition. Fonte: https://www.aura.build/templates/nexura-creative

## Direção visual
- Manter a composição original: proporções, ritmo vertical, blocos de
  conteúdo e atmosfera.
- Preservar hierarquia tipográfica, contraste, espaçamento, estados
  visuais e tratamento de imagens.
- Adaptar responsivamente sem descaracterizar o layout.

## Paleta detectada
- #1c1f26  (22x)
- #262a34  (16x)
- #0b0f19  (5x)
- #22252d  (2x)
- rgba(255,255,255,0.04)  (2x)
- rgba(255,255,255,0.2)  (2x)
- #14161c  (1x)
- rgba(255,255,255,0.1)  (1x)
- rgba(0,0,0,1)  (1x)

## Tipografia detectada
- DotGothic16
- JetBrains Mono

## Estrutura de seções
- High-performance ad creatives that drive growth
- Tasks
- Built for ecom brands that move fast
- Brands love the output
- From brief to scroll-stopper
- We started Nexura because creative was the bottleneck — not media buying.
- Everything in one retainer
- The Nexura advantage
- Ready to scale your creative?

## Regras de implementação
- O `index.html` do template é a fonte principal de verdade.
- Não simplificar a identidade visual: manter imagens, gradientes, cards,
  overlays, efeitos e ritmo da copy.
- Ao converter para React, chegar ao resultado fiel antes de refatorar
  em componentes.
- Trocar apenas textos, links e imagens necessários ao novo negócio.
- Nunca inserir número que o negócio não tenha (avaliação, anos de
  mercado, nº de clientes). Dado não verificado não vai para o site.
