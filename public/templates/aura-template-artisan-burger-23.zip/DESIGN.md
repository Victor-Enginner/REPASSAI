# DESIGN.md — Artisan Burger Restaurant Landing Page Template

Origem: registry privado 77lib
Slug: `aura-template-artisan-burger-23`

## Objetivo
A high-energy, bold restaurant landing page template designed for smashed burger brands and artisanal food services. Fonte: https://www.aura.build/templates/artisan-burger-23

## Direção visual
- Manter a composição original: proporções, ritmo vertical, blocos de
  conteúdo e atmosfera.
- Preservar hierarquia tipográfica, contraste, espaçamento, estados
  visuais e tratamento de imagens.
- Adaptar responsivamente sem descaracterizar o layout.

## Paleta detectada
- #f91814  (34x)
- #f4ebe1  (4x)
- #40220d  (3x)
- #f4a804  (2x)
- #fafafa  (1x)
- #f9cd25  (1x)
- #2c1608  (1x)
- #583115  (1x)

## Tipografia detectada
- Inter
- Modak
- Mouse Memoirs

## Estrutura de seções
- THE BURGER
- JUTEUX ET FROMAGER BIEN GARNI
- UNE NOURRITURE QUI FAIT DU BIEN
- QUALITÉ PURE
- LA QUALITÉ QUI VOYAGE AVEC VOUS
- SENTEZ LA DIFFÉRENCE
- CRAV

## Regras de implementação
- O `index.html` do template é a fonte principal de verdade.
- Não simplificar a identidade visual: manter imagens, gradientes, cards,
  overlays, efeitos e ritmo da copy.
- Ao converter para React, chegar ao resultado fiel antes de refatorar
  em componentes.
- Trocar apenas textos, links e imagens necessários ao novo negócio.
- Nunca inserir número que o negócio não tenha (avaliação, anos de
  mercado, nº de clientes). Dado não verificado não vai para o site.
