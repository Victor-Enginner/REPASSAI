# DESIGN.md — Fluxa AI Finance Landing Page Template

Origem: registry privado 77lib
Slug: `aura-template-fluxa-fintech`

## Objetivo
A high-performance landing page template for AI-driven finance and lending platforms, featuring automated underwriting and repayment tracking workflows. Fonte: https://www.aura.build/templates/fluxa-fintech

## Direção visual
- Manter a composição original: proporções, ritmo vertical, blocos de
  conteúdo e atmosfera.
- Preservar hierarquia tipográfica, contraste, espaçamento, estados
  visuais e tratamento de imagens.
- Adaptar responsivamente sem descaracterizar o layout.

## Paleta detectada
- #06145b  (24x)
- rgba(255,255,255,0.32)  (18x)
- rgba(15,23,42,0.08)  (11x)
- rgba(255,255,255,1)  (10x)
- #2f6bff  (9x)
- #2454f4  (9x)
- #1237d8  (9x)
- rgba(37,84,244,0.36)  (9x)
- rgba(255,255,255,0.38)  (9x)
- rgba(37,84,244,0.28)  (9x)
- rgba(15,23,42,0.07)  (9x)
- rgba(255,255,255,0.9)  (8x)
- rgba(15,23,42,0.06)  (8x)
- rgba(37,99,235,0.22)  (7x)
- rgba(29,78,216,0.22)  (6x)
- #d8e1f3  (5x)

## Tipografia detectada
- Inter

## Estrutura de seções
- Capital for modern businesses, from approval to payout.
- Everything you need, built to perform.
- From approval to payout, fully orchestrated.
- Trusted by lending teams moving faster.
- Pricing designed to scale with lending.
- Frequently asked questions.
- Deploy smarter lending operations with Fluxa.
- FLUXA

## Regras de implementação
- O `index.html` do template é a fonte principal de verdade.
- Não simplificar a identidade visual: manter imagens, gradientes, cards,
  overlays, efeitos e ritmo da copy.
- Ao converter para React, chegar ao resultado fiel antes de refatorar
  em componentes.
- Trocar apenas textos, links e imagens necessários ao novo negócio.
- Nunca inserir número que o negócio não tenha (avaliação, anos de
  mercado, nº de clientes). Dado não verificado não vai para o site.
