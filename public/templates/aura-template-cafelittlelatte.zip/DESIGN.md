# DESIGN.md — Little Latte Cafe Landing Page Template

Origem: registry privado 77lib
Slug: `aura-template-cafelittlelatte`

## Objetivo
A clean, editorial-style coffee shop landing page template designed for cafes, roasteries, and small-batch food service businesses. Fonte: https://www.aura.build/templates/cafelittlelatte

## Direção visual
- Manter a composição original: proporções, ritmo vertical, blocos de
  conteúdo e atmosfera.
- Preservar hierarquia tipográfica, contraste, espaçamento, estados
  visuais e tratamento de imagens.
- Adaptar responsivamente sem descaracterizar o layout.

## Paleta detectada
- #252525  (66x)
- #efeee6  (7x)

## Tipografia detectada
- (nenhuma externa)

## Estrutura de seções
- More than a coffee — it’s a pause
- Small-batch espresso, served with soul
- Rooted in flavor, fueled by community
- Coffee. Pastries. And everything you crave.
- Fresh made, every day.

## Regras de implementação
- O `index.html` do template é a fonte principal de verdade.
- Não simplificar a identidade visual: manter imagens, gradientes, cards,
  overlays, efeitos e ritmo da copy.
- Ao converter para React, chegar ao resultado fiel antes de refatorar
  em componentes.
- Trocar apenas textos, links e imagens necessários ao novo negócio.
- Nunca inserir número que o negócio não tenha (avaliação, anos de
  mercado, nº de clientes). Dado não verificado não vai para o site.
