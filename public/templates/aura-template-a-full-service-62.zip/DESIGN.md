# DESIGN.md — Living Culture Studios Retreat Template

Origem: registry privado 77lib
Slug: `aura-template-a-full-service-62`

## Objetivo
A sophisticated hospitality and experience design template for showcasing wellness retreats, premium venues, and regenerative tourism services. Fonte: https://www.aura.build/templates/a-full-service-62

## Direção visual
- Manter a composição original: proporções, ritmo vertical, blocos de
  conteúdo e atmosfera.
- Preservar hierarquia tipográfica, contraste, espaçamento, estados
  visuais e tratamento de imagens.
- Adaptar responsivamente sem descaracterizar o layout.

## Paleta detectada
- rgba(0, 0, 0, 1)  (15x)
- rgba(0, 0, 0, 0)  (14x)
- rgba(255, 255, 255, 0.03)  (1x)
- rgba(255, 255, 255, 0.08)  (1x)
- rgba(255, 255, 255, 0.7)  (1x)
- rgba(0, 0, 0, 0.05)  (1x)

## Tipografia detectada
- Inter
- Fraunces
- Manrope

## Estrutura de seções
- Retreat, reimagined from the inside out.
- We design the feeling first.
- Living Culture Studios. Emotional Architecture.
- Featured Properties
- Let’s Build an Experience Together.

## Regras de implementação
- O `index.html` do template é a fonte principal de verdade.
- Não simplificar a identidade visual: manter imagens, gradientes, cards,
  overlays, efeitos e ritmo da copy.
- Ao converter para React, chegar ao resultado fiel antes de refatorar
  em componentes.
- Trocar apenas textos, links e imagens necessários ao novo negócio.
- Nunca inserir número que o negócio não tenha (avaliação, anos de
  mercado, nº de clientes). Dado não verificado não vai para o site.
