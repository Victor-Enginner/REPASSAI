# DESIGN.md — Soluna Premium Yoga Studio Template

Origem: registry privado 77lib
Slug: `aura-template-soluna-yoga-studio-43`

## Objetivo
A serene and minimalist landing page template designed for yoga studios and wellness centers to showcase classes, teachers, and memberships. Fonte: https://www.aura.build/templates/soluna-yoga-studio-43

## Direção visual
- Manter a composição original: proporções, ritmo vertical, blocos de
  conteúdo e atmosfera.
- Preservar hierarquia tipográfica, contraste, espaçamento, estados
  visuais e tratamento de imagens.
- Adaptar responsivamente sem descaracterizar o layout.

## Paleta detectada
- #1a1a1a  (109x)
- #5c5c5a  (46x)
- #5d674f  (31x)
- #dcdacd  (21x)
- #f5f4f0  (14x)
- #e8eae4  (11x)
- #333  (2x)
- #f2ece5  (2x)
- #a0a09e  (2x)
- #4a523f  (1x)

## Tipografia detectada
- Inter

## Estrutura de seções
- Move.Breathe.Become You.
- Rooted in tradition, designed for modern life.
- Discover your flow
- Upcoming Schedule
- Meet your guides
- Simple, transparent pricing
- Begin your journey.

## Regras de implementação
- O `index.html` do template é a fonte principal de verdade.
- Não simplificar a identidade visual: manter imagens, gradientes, cards,
  overlays, efeitos e ritmo da copy.
- Ao converter para React, chegar ao resultado fiel antes de refatorar
  em componentes.
- Trocar apenas textos, links e imagens necessários ao novo negócio.
- Nunca inserir número que o negócio não tenha (avaliação, anos de
  mercado, nº de clientes). Dado não verificado não vai para o site.
