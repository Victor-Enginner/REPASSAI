# DESIGN.md — STRIDE Personal Growth Landing Page Template

Origem: registry privado 77lib
Slug: `aura-template-clintoncoheniii`

## Objetivo
A high-performance personal brand and coaching template featuring a futuristic dark bento-grid design for health, lifestyle, and productivity systems. Fonte: https://www.aura.build/templates/clintoncoheniii

## Direção visual
- Manter a composição original: proporções, ritmo vertical, blocos de
  conteúdo e atmosfera.
- Preservar hierarquia tipográfica, contraste, espaçamento, estados
  visuais e tratamento de imagens.
- Adaptar responsivamente sem descaracterizar o layout.

## Paleta detectada
- #00f3ff  (81x)
- #050505  (11x)
- rgba(255,255,255,0.03)  (4x)
- rgba(255, 255, 255, 0.05)  (2x)
- rgba(0,243,255,0.5)  (2x)
- rgba(201,201,201,.20)  (2x)
- rgb(201 201 201 / 0)  (2x)
- rgba(255,255,255,.55)  (2x)
- #33f5ff  (1x)
- #004d52  (1x)
- #e5e5e5  (1x)
- #262626  (1x)
- #0a0a0a  (1x)
- #080808  (1x)
- #030303  (1x)
- #c9c9c9  (1x)

## Tipografia detectada
- Syne
- Instrument Serif
- Inter

## Estrutura de seções
- WALK with Purpose.
- The Walk
- Built for the Chaos Current.
- Navigate the Chaos Current.
- What I'm Building.
- The Result: Clarity.
- Ready to Take Your First Step?

## Regras de implementação
- O `index.html` do template é a fonte principal de verdade.
- Não simplificar a identidade visual: manter imagens, gradientes, cards,
  overlays, efeitos e ritmo da copy.
- Ao converter para React, chegar ao resultado fiel antes de refatorar
  em componentes.
- Trocar apenas textos, links e imagens necessários ao novo negócio.
- Nunca inserir número que o negócio não tenha (avaliação, anos de
  mercado, nº de clientes). Dado não verificado não vai para o site.
