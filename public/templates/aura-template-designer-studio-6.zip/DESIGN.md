# DESIGN.md — Designer Studio SaaS Landing Page Template

Origem: registry privado 77lib
Slug: `aura-template-designer-studio-6`

## Objetivo
A high-performance portfolio and design studio template featuring WebGL backgrounds and precision-engineered typography for a premium digital presence. Fonte: https://www.aura.build/templates/designer-studio-6

## Direção visual
- Manter a composição original: proporções, ritmo vertical, blocos de
  conteúdo e atmosfera.
- Preservar hierarquia tipográfica, contraste, espaçamento, estados
  visuais e tratamento de imagens.
- Adaptar responsivamente sem descaracterizar o layout.

## Paleta detectada
- #f5f5f5  (3x)
- #737373  (3x)
- #ffffff  (2x)
- #fff  (2x)
- #080808  (1x)
- #a3a3a3  (1x)
- #525252  (1x)
- rgba(8,8,8,0.85)  (1x)
- rgba(0,0,0,0.5)  (1x)
- rgba(200,200,200,0.5)  (1x)
- rgba(255,255,255,0.08)  (1x)
- rgba(255,255,255,0.02)  (1x)
- rgba(0,0,0,0.3)  (1x)
- rgba(255,255,255,0.4)  (1x)

## Tipografia detectada
- Inter
- JetBrains Mono

## Estrutura de seções
- Designing at the pixel level
- Selected Works
- Our Process
- The Philosophy

## Regras de implementação
- O `index.html` do template é a fonte principal de verdade.
- Não simplificar a identidade visual: manter imagens, gradientes, cards,
  overlays, efeitos e ritmo da copy.
- Ao converter para React, chegar ao resultado fiel antes de refatorar
  em componentes.
- Trocar apenas textos, links e imagens necessários ao novo negócio.
- Nunca inserir número que o negócio não tenha (avaliação, anos de
  mercado, nº de clientes). Dado não verificado não vai para o site.
