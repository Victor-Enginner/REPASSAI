# DESIGN.md — Ina Beauty Studio Plovdiv

Origem: registry privado 77lib
Slug: `aura-template-beauty-studio-72`

## Objetivo
A reusable landing page template for beauty studios, salons, and solo estheticians to showcase services, pricing, gallery highlights, and booking details. Fonte: https://www.aura.build/templates/beauty-studio-72

## Direção visual
- Manter a composição original: proporções, ritmo vertical, blocos de
  conteúdo e atmosfera.
- Preservar hierarquia tipográfica, contraste, espaçamento, estados
  visuais e tratamento de imagens.
- Adaptar responsivamente sem descaracterizar o layout.

## Paleta detectada
- #a8832a  (66x)
- #2c2416  (36x)
- #f5f0e8  (32x)
- #c9a84c  (27x)
- #7a6a4f  (17x)
- #6f624a  (10x)
- #e6ddcf  (9x)
- rgba(44,36,22,0.10)  (9x)
- #e4d8c8  (8x)
- #f8f4ec  (7x)
- #c4527a  (7x)
- #ede8dc  (7x)
- #8a7a5f  (7x)
- #8b6b23  (6x)
- #f7f1e8  (6x)
- rgba(44,36,22,0.05)  (6x)

## Tipografia detectada
- Cormorant Garamond
- DM Sans
- Dancing Script

## Estrutura de seções
- Красота с грижа
- Миглопластика
- Ина и нейното студио
- Галерия
- Контакти

## Regras de implementação
- O `index.html` do template é a fonte principal de verdade.
- Não simplificar a identidade visual: manter imagens, gradientes, cards,
  overlays, efeitos e ritmo da copy.
- Ao converter para React, chegar ao resultado fiel antes de refatorar
  em componentes.
- Trocar apenas textos, links e imagens necessários ao novo negócio.
- Nunca inserir número que o negócio não tenha (avaliação, anos de
  mercado, nº de clientes). Dado não verificado não vai para o site.
