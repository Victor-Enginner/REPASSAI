# DESIGN.md — CIRON Performance Bicycle Landing Page Template

Origem: registry privado 77lib
Slug: `aura-template-velocity-performanc`

## Objetivo
A high-end, animated SaaS-style template designed for performance brands and product engineering showcases. Fonte: https://www.aura.build/templates/velocity-performanc

## Direção visual
- Manter a composição original: proporções, ritmo vertical, blocos de
  conteúdo e atmosfera.
- Preservar hierarquia tipográfica, contraste, espaçamento, estados
  visuais e tratamento de imagens.
- Adaptar responsivamente sem descaracterizar o layout.

## Paleta detectada
- #303833  (18x)
- #fff  (13x)
- #f7f7f3  (12x)
- #dcded9  (12x)
- #111827  (12x)
- #000  (11x)
- #9a9f9a  (11x)
- #111  (10x)
- #ffffff  (9x)
- #ff4f18  (8x)
- #b9bbb7  (7x)
- #0d1110  (6x)
- #e4e5e1  (5x)
- #d8dad5  (5x)
- #969b97  (5x)
- #e0e1dc  (5x)

## Tipografia detectada
- Inter
- JetBrains Mono

## Estrutura de seções
- Engineered for the pursuit of speed.
- Performance should feel effortless
- Carbon architecture
- One integrated performance system
- CIRON C1
- Performance, Engineered As One.
- Road, aero, all-road, and gravel performance. One engineering language.
- Three CIRON expressions. One performance platform.
- Inside Every CIRON.
- Four models, one performance language. Tuned for different ways to ride.
- Refine the ride, down to the detail.
- Experience CIRON.

## Regras de implementação
- O `index.html` do template é a fonte principal de verdade.
- Não simplificar a identidade visual: manter imagens, gradientes, cards,
  overlays, efeitos e ritmo da copy.
- Ao converter para React, chegar ao resultado fiel antes de refatorar
  em componentes.
- Trocar apenas textos, links e imagens necessários ao novo negócio.
- Nunca inserir número que o negócio não tenha (avaliação, anos de
  mercado, nº de clientes). Dado não verificado não vai para o site.
