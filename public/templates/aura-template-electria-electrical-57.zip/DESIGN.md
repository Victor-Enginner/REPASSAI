# DESIGN.md — Electria Electrical Services Landing Page Template - home

Origem: registry privado 77lib
Slug: `aura-template-electria-electrical-57`

## Objetivo
Template gratuito importado da Aura. Fonte: https://www.aura.build/templates/electria-electrical-57

## Direção visual
- Manter a composição original: proporções, ritmo vertical, blocos de
  conteúdo e atmosfera.
- Preservar hierarquia tipográfica, contraste, espaçamento, estados
  visuais e tratamento de imagens.
- Adaptar responsivamente sem descaracterizar o layout.

## Paleta detectada
- #222  (3x)
- #333  (2x)
- rgba(255,255,255,0.03)  (2x)
- #1a1a1a  (1x)
- #444  (1x)
- #facc15  (1x)
- #0a0a0a  (1x)
- #171717  (1x)

## Tipografia detectada
- Inter
- Geist
- Space Grotesk

## Estrutura de seções
- RELIABLE ELECTRICAL SERVICES, WHENEVER YOU NEED THEM
- WHAT WE DO
- WHERE WE OPERATE
- RELIABLE AND EFFICIENT
- PROVEN EXPERTISE YOU CAN TRUST
- FREQUENTLY ASKED QUESTIONS
- WE HELPED THESE CLIENTS
- READ ABOUT ELECTRICITY
- LET US SOLVE YOUR ELECTRICAL PROBLEMS

## Regras de implementação
- O `index.html` do template é a fonte principal de verdade.
- Não simplificar a identidade visual: manter imagens, gradientes, cards,
  overlays, efeitos e ritmo da copy.
- Ao converter para React, chegar ao resultado fiel antes de refatorar
  em componentes.
- Trocar apenas textos, links e imagens necessários ao novo negócio.
- Nunca inserir número que o negócio não tenha (avaliação, anos de
  mercado, nº de clientes). Dado não verificado não vai para o site.
