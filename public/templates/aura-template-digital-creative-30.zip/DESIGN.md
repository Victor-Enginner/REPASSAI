# DESIGN.md — Creative Design Studio Landing Page Template

Origem: registry privado 77lib
Slug: `aura-template-digital-creative-30`

## Objetivo
A high-end, immersive digital studio template designed for creative agencies to showcase premium portfolios and brand experiences. Fonte: https://www.aura.build/templates/digital-creative-30

## Direção visual
- Manter a composição original: proporções, ritmo vertical, blocos de
  conteúdo e atmosfera.
- Preservar hierarquia tipográfica, contraste, espaçamento, estados
  visuais e tratamento de imagens.
- Adaptar responsivamente sem descaracterizar o layout.

## Paleta detectada
- #e0ccbb  (14x)
- #070707  (4x)
- #f8f8f8  (1x)

## Tipografia detectada
- Inter

## Estrutura de seções
- Digital Design Expérience
- Réalisations
- Voir la Vidéo
- Faire Passer le Mot
- Notre Histoire

## Regras de implementação
- O `index.html` do template é a fonte principal de verdade.
- Não simplificar a identidade visual: manter imagens, gradientes, cards,
  overlays, efeitos e ritmo da copy.
- Ao converter para React, chegar ao resultado fiel antes de refatorar
  em componentes.
- Trocar apenas textos, links e imagens necessários ao novo negócio.
- Nunca inserir número que o negócio não tenha (avaliação, anos de
  mercado, nº de clientes). Dado não verificado não vai para o site.
