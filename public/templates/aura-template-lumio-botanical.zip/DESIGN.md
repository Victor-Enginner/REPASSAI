# DESIGN.md — Lumio Botanical Landing Page Template

Origem: registry privado 77lib
Slug: `aura-template-lumio-botanical`

## Objetivo
A high-end, animated botanical management interface template designed for horticulture technology and smart garden displays. Fonte: https://www.aura.build/templates/lumio-botanical

## Direção visual
- Manter a composição original: proporções, ritmo vertical, blocos de
  conteúdo e atmosfera.
- Preservar hierarquia tipográfica, contraste, espaçamento, estados
  visuais e tratamento de imagens.
- Adaptar responsivamente sem descaracterizar o layout.

## Paleta detectada
- #2b1621  (90x)
- #1e0c1f  (62x)
- #f8ede2  (49x)
- #f9efe4  (5x)
- #f6d6ff  (5x)
- #5b223e  (4x)
- #d946ef  (3x)
- #022c22  (3x)
- #ffffff  (3x)
- #10b981  (3x)
- rgba(43,22,33,.03)  (3x)
- #a7f3d0  (2x)
- #f0fdf4  (2x)
- #a78bfa  (2x)
- rgba(43,22,33,0.20)  (2x)
- rgba(2, 1, 2, 0.004)  (2x)

## Tipografia detectada
- Plus Jakarta Sans

## Estrutura de seções
- Rare flora, staged in a living management system.
- SEEDLING EMERGENCE
- FOLIAGE EXPANSION
- CANOPY DEVELOPMENT
- A calibrated six-month blooming cycle.
- Connect your sensors.

## Regras de implementação
- O `index.html` do template é a fonte principal de verdade.
- Não simplificar a identidade visual: manter imagens, gradientes, cards,
  overlays, efeitos e ritmo da copy.
- Ao converter para React, chegar ao resultado fiel antes de refatorar
  em componentes.
- Trocar apenas textos, links e imagens necessários ao novo negócio.
- Nunca inserir número que o negócio não tenha (avaliação, anos de
  mercado, nº de clientes). Dado não verificado não vai para o site.
