# DESIGN.md — Trace0 Cybersecurity Advisory Landing Page Template

Origem: registry privado 77lib
Slug: `aura-template-cybersecur-advisory-69`

## Objetivo
An elite, research-led cybersecurity advisory template featuring immersive 3D WebGL visuals, adversarial service showcases, and professional engagement models. Fonte: https://www.aura.build/templates/cybersecur-advisory-69

## Direção visual
- Manter a composição original: proporções, ritmo vertical, blocos de
  conteúdo e atmosfera.
- Preservar hierarquia tipográfica, contraste, espaçamento, estados
  visuais e tratamento de imagens.
- Adaptar responsivamente sem descaracterizar o layout.

## Paleta detectada
- #ff5f1f  (6x)
- rgba(255,255,255,0.00)  (4x)
- rgba(15,15,15,0.4)  (4x)
- rgba(25,25,25,0.5)  (4x)
- #030303  (2x)
- #1e1e1e  (2x)
- #000000  (2x)
- rgba(20, 20, 20, 0.4)  (2x)
- rgba(0, 0, 0, 0.00)  (2x)
- rgba(255,255,255,0.18)  (2x)
- rgba(255,255,255,0.10)  (2x)
- rgba(15, 15, 15, 0.4)  (2x)
- #fafafa  (1x)
- #a3a3a3  (1x)
- #050508  (1x)
- #e6551c  (1x)

## Tipografia detectada
- Orbitron
- Sarpanch

## Estrutura de seções
- Trace threats to their origin.
- We don't just find problems.
- We exist to eliminate structural risk.
- Engagement Process Controlled adversarial activity.
- Deliverables &amp; Artifacts.
- Scope of Advisory Services
- Engagement Models
- Ready to discuss your security needs?

## Regras de implementação
- O `index.html` do template é a fonte principal de verdade.
- Não simplificar a identidade visual: manter imagens, gradientes, cards,
  overlays, efeitos e ritmo da copy.
- Ao converter para React, chegar ao resultado fiel antes de refatorar
  em componentes.
- Trocar apenas textos, links e imagens necessários ao novo negócio.
- Nunca inserir número que o negócio não tenha (avaliação, anos de
  mercado, nº de clientes). Dado não verificado não vai para o site.
