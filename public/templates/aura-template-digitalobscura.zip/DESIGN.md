# DESIGN.md — Digital Obscura Visual Archive Template

Origem: registry privado 77lib
Slug: `aura-template-digitalobscura`

## Objetivo
A cinematic, high-concept portfolio and digital exhibition template designed for photographers and artists looking to document memories with a technical, archival aesthetic. Fonte: https://www.aura.build/templates/digitalobscura

## Direção visual
- Manter a composição original: proporções, ritmo vertical, blocos de
  conteúdo e atmosfera.
- Preservar hierarquia tipográfica, contraste, espaçamento, estados
  visuais e tratamento de imagens.
- Adaptar responsivamente sem descaracterizar o layout.

## Paleta detectada
- rgba(0, 0, 0, 0.04)  (2x)
- rgba(255,255,255,0.7)  (2x)
- #f4f3f0  (1x)
- #1a1a1a  (1x)
- #888888  (1x)
- #d1d1d1  (1x)
- #a0b0c0  (1x)
- #e5e5e5  (1x)
- #ebeae6  (1x)
- #111  (1x)
- rgba(18, 16, 16, 0)  (1x)
- rgba(0, 0, 0, 0.02)  (1x)

## Tipografia detectada
- Inter
- JetBrains Mono

## Estrutura de seções
- Digital Obscura
- What remains when the signal stops?
- "The archive never fully disappears."
- Initiate Transmission.

## Regras de implementação
- O `index.html` do template é a fonte principal de verdade.
- Não simplificar a identidade visual: manter imagens, gradientes, cards,
  overlays, efeitos e ritmo da copy.
- Ao converter para React, chegar ao resultado fiel antes de refatorar
  em componentes.
- Trocar apenas textos, links e imagens necessários ao novo negócio.
- Nunca inserir número que o negócio não tenha (avaliação, anos de
  mercado, nº de clientes). Dado não verificado não vai para o site.
