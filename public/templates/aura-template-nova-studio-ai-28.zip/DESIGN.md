# DESIGN.md — Kindling AI Operations Landing Page

Origem: registry privado 77lib
Slug: `aura-template-nova-studio-ai-28`

## Objetivo
A high-performance landing page template designed for AI automation agencies and operational consultants to showcase system-driven scale. Fonte: https://www.aura.build/templates/nova-studio-ai-28

## Direção visual
- Manter a composição original: proporções, ritmo vertical, blocos de
  conteúdo e atmosfera.
- Preservar hierarquia tipográfica, contraste, espaçamento, estados
  visuais e tratamento de imagens.
- Adaptar responsivamente sem descaracterizar o layout.

## Paleta detectada
- #fe4c00  (46x)
- rgb(255, 255, 255)  (6x)
- rgb(254, 76, 0)  (5x)
- #000000  (4x)
- rgba(254,76,0,0.3)  (4x)
- #000  (2x)
- #e64400  (2x)
- rgba(0, 0, 0, 0.18)  (2x)
- rgba(255,255,255,0.06)  (2x)
- rgba(255,255,255,0.08)  (2x)
- #ffffff  (1x)
- #fff  (1x)
- #cc0000  (1x)
- rgba(255,255,255,0.8)  (1x)
- rgba(255,255,255,0.5)  (1x)
- rgba(0,0,0,0.22)  (1x)

## Tipografia detectada
- Space Grotesk
- Space Mono
- Inter
- Montserrat
- Plus Jakarta Sans
- Playfair Display

## Estrutura de seções
- One Spark. Your Systems.
- Infinite Scale.
- Scale breaks breaks breaks duct tape.
- Stop being the system. Install one.
- Built for how you actually operate.
- Our Approach
- Start Here
- Results, not rhetoric
- This is the leverage shift.
- What we build. In the wild.
- Some highlighted case studies:
- Why Kindling?

## Regras de implementação
- O `index.html` do template é a fonte principal de verdade.
- Não simplificar a identidade visual: manter imagens, gradientes, cards,
  overlays, efeitos e ritmo da copy.
- Ao converter para React, chegar ao resultado fiel antes de refatorar
  em componentes.
- Trocar apenas textos, links e imagens necessários ao novo negócio.
- Nunca inserir número que o negócio não tenha (avaliação, anos de
  mercado, nº de clientes). Dado não verificado não vai para o site.
