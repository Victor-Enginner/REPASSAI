# DESIGN.md — Holistic Health  Physiotherapy Landing Page Template

Origem: registry privado 77lib
Slug: `aura-template-holistic-physiother-13`

## Objetivo
A serene and professional landing page template designed for holistic therapists, physiotherapists, and wellness practitioners seeking a sophisticated dark-themed presence. Fonte: https://www.aura.build/templates/holistic-physiother-13

## Direção visual
- Manter a composição original: proporções, ritmo vertical, blocos de
  conteúdo e atmosfera.
- Preservar hierarquia tipográfica, contraste, espaçamento, estados
  visuais e tratamento de imagens.
- Adaptar responsivamente sem descaracterizar o layout.

## Paleta detectada
- #a2b5b1  (99x)
- #4ec3a6  (50x)
- #404040  (40x)
- #262626  (16x)
- #1a1a1a  (3x)
- rgba(78,195,166,0.12)  (1x)
- rgba(38,38,38,0)  (1x)
- rgba(38,38,38,0.8)  (1x)
- rgba(78,195,166,0.05)  (1x)

## Tipografia detectada
- Inter

## Estrutura de seções
- FizjoKOliber
- O mnie
- Jak wygląda współpraca ze mną?
- Oferta
- Cennik
- Rozpocznijmy

## Regras de implementação
- O `index.html` do template é a fonte principal de verdade.
- Não simplificar a identidade visual: manter imagens, gradientes, cards,
  overlays, efeitos e ritmo da copy.
- Ao converter para React, chegar ao resultado fiel antes de refatorar
  em componentes.
- Trocar apenas textos, links e imagens necessários ao novo negócio.
- Nunca inserir número que o negócio não tenha (avaliação, anos de
  mercado, nº de clientes). Dado não verificado não vai para o site.
