# DESIGN.md — Outdoor Sales Agency Landing Page Template

Origem: registry privado 77lib
Slug: `aura-template-birka-outdoor-21`

## Objetivo
A high-end, dark-themed template designed for sales agencies, B2B services, and premium outdoor brand distribution partners. Fonte: https://www.aura.build/templates/birka-outdoor-21

## Direção visual
- Manter a composição original: proporções, ritmo vertical, blocos de
  conteúdo e atmosfera.
- Preservar hierarquia tipográfica, contraste, espaçamento, estados
  visuais e tratamento de imagens.
- Adaptar responsivamente sem descaracterizar o layout.

## Paleta detectada
- #d8b485  (49x)
- #0c0c0e  (10x)
- #09090b  (8x)
- #c2a277  (4x)
- #111114  (4x)
- #27272a  (1x)
- #3f3f46  (1x)
- rgba(216,180,133,.25)  (1x)

## Tipografia detectada
- Inter

## Estrutura de seções
- BIRKA
- Sales Agency
- We help outdoor brands grow in the right way.
- Trusted by premium outdoor brands.
- The Adriatic Region.
- Ready to grow your brand?

## Regras de implementação
- O `index.html` do template é a fonte principal de verdade.
- Não simplificar a identidade visual: manter imagens, gradientes, cards,
  overlays, efeitos e ritmo da copy.
- Ao converter para React, chegar ao resultado fiel antes de refatorar
  em componentes.
- Trocar apenas textos, links e imagens necessários ao novo negócio.
- Nunca inserir número que o negócio não tenha (avaliação, anos de
  mercado, nº de clientes). Dado não verificado não vai para o site.
