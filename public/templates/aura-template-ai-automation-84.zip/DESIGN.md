# DESIGN.md — AI Automation Agency Landing Page Template

Origem: registry privado 77lib
Slug: `aura-template-ai-automation-84`

## Objetivo
A high-performance dark-themed template designed for AI agencies to showcase intelligent workflows, automation services, and tool integrations. Fonte: https://www.aura.build/templates/ai-automation-84

## Direção visual
- Manter a composição original: proporções, ritmo vertical, blocos de
  conteúdo e atmosfera.
- Preservar hierarquia tipográfica, contraste, espaçamento, estados
  visuais e tratamento de imagens.
- Adaptar responsivamente sem descaracterizar o layout.

## Paleta detectada
- #ffffff  (10x)
- #000000  (10x)
- rgb(255, 255, 255)  (9x)
- rgba(0,0,0,0.5)  (7x)
- #0c0c0e  (6x)
- #fff  (4x)
- rgba(255,255,255,1)  (4x)
- rgba(255,255,255,0.1)  (4x)
- #09090b  (3x)
- #3f3f46  (3x)
- #38bdf8  (3x)
- rgba(255, 255, 255, 0.2)  (3x)
- rgba(255, 255, 255, 0)  (3x)
- rgb(0, 0, 0)  (3x)
- #0ea5e9  (2x)
- #1e293b  (2x)

## Tipografia detectada
- Inter
- Newsreader

## Estrutura de seções
- Automate with AI agents
- Intelligent workflows powered by AI agents
- Connect all your tools &amp; data
- Get help from AI automation experts
- Ready to automate your business?

## Regras de implementação
- O `index.html` do template é a fonte principal de verdade.
- Não simplificar a identidade visual: manter imagens, gradientes, cards,
  overlays, efeitos e ritmo da copy.
- Ao converter para React, chegar ao resultado fiel antes de refatorar
  em componentes.
- Trocar apenas textos, links e imagens necessários ao novo negócio.
- Nunca inserir número que o negócio não tenha (avaliação, anos de
  mercado, nº de clientes). Dado não verificado não vai para o site.
