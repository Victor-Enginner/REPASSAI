# DESIGN.md — Beauty Institute  Wellness Landing Page Template

Origem: registry privado 77lib
Slug: `aura-template-testimagedesoi`

## Objetivo
A refined, professional website template for high-end beauty institutes featuring automated booking integration and service showcases. Fonte: https://www.aura.build/templates/testimagedesoi

## Direção visual
- Manter a composição original: proporções, ritmo vertical, blocos de
  conteúdo e atmosfera.
- Preservar hierarquia tipográfica, contraste, espaçamento, estados
  visuais e tratamento de imagens.
- Adaptar responsivamente sem descaracterizar o layout.

## Paleta detectada
- #c8927a  (18x)
- #2e2a27  (16x)
- rgba(255, 255, 255, 0.35)  (2x)
- rgba(255, 255, 255, 0.38)  (2x)
- #ffffff  (1x)
- #faf8f6  (1x)
- #f5f0eb  (1x)
- #ede6de  (1x)
- #ded4c7  (1x)
- #1c1c1c  (1x)
- #5a5350  (1x)
- #8f8a87  (1x)
- #ddb09c  (1x)
- #edd5ca  (1x)
- #f7ede8  (1x)
- #e8d5c8  (1x)

## Tipografia detectada
- Cormorant Garamond
- Nunito Sans

## Estrutura de seções
- Votre beauté, une parenthèse qui vous ressemble.
- L'attentionque vous méritez
- L'expérienceImage de Soi
- Hydrafacial®La révolution peau
- Nos soins &amp; services
- Elles nous font confiance
- Prenez rendez-vousdès aujourd'hui

## Regras de implementação
- O `index.html` do template é a fonte principal de verdade.
- Não simplificar a identidade visual: manter imagens, gradientes, cards,
  overlays, efeitos e ritmo da copy.
- Ao converter para React, chegar ao resultado fiel antes de refatorar
  em componentes.
- Trocar apenas textos, links e imagens necessários ao novo negócio.
- Nunca inserir número que o negócio não tenha (avaliação, anos de
  mercado, nº de clientes). Dado não verificado não vai para o site.
