# DESIGN.md — KÁVA Coffee Shop Landing Page Template

Origem: registry privado 77lib
Slug: `aura-template-kavaandcocoffee`

## Objetivo
A premium, dark-themed cafe and restaurant template designed for modern coffee shops, bakeries, and local eateries looking for a stylish web presence. Fonte: https://www.aura.build/templates/kavaandcocoffee

## Direção visual
- Manter a composição original: proporções, ritmo vertical, blocos de
  conteúdo e atmosfera.
- Preservar hierarquia tipográfica, contraste, espaçamento, estados
  visuais e tratamento de imagens.
- Adaptar responsivamente sem descaracterizar o layout.

## Paleta detectada
- #100c08  (7x)
- #0d0906  (2x)
- #f4eadc  (2x)
- #120  (2x)
- #fef3c7  (1x)
- #fff8ed  (1x)
- #120d08  (1x)
- rgba(254, 243, 199, 0.25)  (1x)
- rgba(251, 191, 36, 0.12)  (1x)
- rgba(120, 53, 15, 0.18)  (1x)
- rgba(251, 191, 36, 0.22)  (1x)
- rgba(0, 0, 0, 0.22)  (1x)
- rgba(146, 64, 14, 0.28)  (1x)
- rgba(255,255,255,0.08)  (1x)
- rgba(254,243,199,0.20)  (1x)
- rgba(251,191,36,0.08)  (1x)

## Tipografia detectada
- Inter
- Geist
- Google Sans
- Space Mono
- Lora
- Instrument Serif
- Syne

## Estrutura de seções
- A New Era of Coffee in Mill Bay
- A vibrant Mill Bay café for coffee, chai, smoothies, teas, and pastry.
- Coffee, food, and good energy.
- Coffee, specialty drinks, soups, sandwiches, and a full pastry case.
- Details that make the stop memorable.
- Loved for selection, service, and quality.
- Find KÁVA &amp; Co. Coffee in Mill Bay, BC.

## Regras de implementação
- O `index.html` do template é a fonte principal de verdade.
- Não simplificar a identidade visual: manter imagens, gradientes, cards,
  overlays, efeitos e ritmo da copy.
- Ao converter para React, chegar ao resultado fiel antes de refatorar
  em componentes.
- Trocar apenas textos, links e imagens necessários ao novo negócio.
- Nunca inserir número que o negócio não tenha (avaliação, anos de
  mercado, nº de clientes). Dado não verificado não vai para o site.
