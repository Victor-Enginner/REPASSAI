# DESIGN.md — TheCodeCompany

Origem: registry privado 77lib
Slug: `aura-template-the-code-company-35`

## Objetivo
Template gratuito importado da Aura. Fonte: https://www.aura.build/templates/the-code-company-35

## Direção visual
- Manter a composição original: proporções, ritmo vertical, blocos de
  conteúdo e atmosfera.
- Preservar hierarquia tipográfica, contraste, espaçamento, estados
  visuais e tratamento de imagens.
- Adaptar responsivamente sem descaracterizar o layout.

## Paleta detectada
- #f5f4e8  (4x)
- #e4e4e7  (2x)
- #f2f2f2  (2x)
- #0a0a0a  (2x)
- #f5f5f5  (2x)
- rgb(255, 255, 255)  (2x)
- #000000  (1x)
- rgba(0,0,0,0.5)  (1x)

## Tipografia detectada
- Inter

## Estrutura de seções
- CODIGO. SONIDO. EMOCIÓN.
- Stiven&nbsp;Castillo

## Regras de implementação
- O `index.html` do template é a fonte principal de verdade.
- Não simplificar a identidade visual: manter imagens, gradientes, cards,
  overlays, efeitos e ritmo da copy.
- Ao converter para React, chegar ao resultado fiel antes de refatorar
  em componentes.
- Trocar apenas textos, links e imagens necessários ao novo negócio.
- Nunca inserir número que o negócio não tenha (avaliação, anos de
  mercado, nº de clientes). Dado não verificado não vai para o site.
