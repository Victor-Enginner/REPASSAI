# DESIGN.md — Soda 3D Hero

Slug: `soda-3d-hero`

## Objetivo
Hero de página inteira para bebida, construído em torno de um modelo 3D real
que reage ao cursor. É o template mais pesado do catálogo e o único que usa
WebGL — serve a marca que quer demonstrar produto, não a que quer vender
serviço local.

## Direção visual
- Fundo em gradiente radial escuro que morfa entre teal (Classic) e azul
  (Zero Lime) em 1.5s.
- Tipografia cursiva `Galada` em escala enorme: `clamp(5rem, 10vw, 12rem)`
  com `line-height: 0.8`. É a assinatura da página.
- Acento rosa `#fbcfe8` em três lugares e só neles: item de nav ativo, ícone
  de mais no CTA, borda do card selecionado.
- Glassmorphism na navegação e nos cards: `backdrop-filter: blur(20px)`.

## Movimento — o que não pode ser simplificado
O valor deste template está no movimento. Reduzir qualquer item abaixo
descaracteriza a página:

- Lata inclina seguindo o cursor, com suavização `lerp 0.05`.
- Cerejas repelidas pelo ponteiro: raio 400px, força -80, `lerp 0.1`.
- Parallax em três profundidades: frente ×60, fundo ×-30, folhas ×-15.
- Troca de sabor: implosão ao centro (0.5s), troca do modelo, explosão para
  posição aleatória (0.9s, `back.out(1.5)`), enquanto a lata gira 720° com
  blur que sobe a 15px e volta a zero.
- Bolhas nascem a cada 400ms e sobem -110vh girando 360°.

## Estrutura de camadas (z-index)
A ordem importa e é contraintuitiva: cerejas de frente ficam ACIMA do texto.

- folhas: -1
- cerejas de fundo: 0
- lata: 1 (vira 50 durante a troca, para passar à frente das cerejas)
- colunas de texto: 100
- cerejas de frente: 110
- header: 100

## Regras de implementação
- O `index.html` é a fonte de verdade: um arquivo, sem build.
- Não trocar `<model-viewer>` por imagem: o produto girando É a página.
- A página não rola (`overflow: hidden; height: 100vh`). Não adicionar seções
  abaixo sem redesenhar o conceito.
- Sem cursor não há interação — em toque a página vira estática. É limite do
  conceito, não defeito.
- Trocar apenas textos, preços, sabores e assets do novo negócio.
- Nunca inserir número que o negócio não tenha (avaliação, prêmio, anos de
  mercado). O selo "DESIGN AWARDS / PREMIUM BEVERAGE 2025" é do exemplo:
  remover ou substituir por prêmio real.
