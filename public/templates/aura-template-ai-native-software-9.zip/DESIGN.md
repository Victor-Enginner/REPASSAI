# DESIGN.md — AI-Native Software Agency Template

Origem: registry privado 77lib
Slug: `aura-template-ai-native-software-9`

## Objetivo
A high-performance, dark-themed agency template designed for software developers and creative technologists building AI-powered products. Fonte: https://www.aura.build/templates/ai-native-software-9

## Direção visual
- Manter a composição original: proporções, ritmo vertical, blocos de
  conteúdo e atmosfera.
- Preservar hierarquia tipográfica, contraste, espaçamento, estados
  visuais e tratamento de imagens.
- Adaptar responsivamente sem descaracterizar o layout.

## Paleta detectada
- rgba(0,0,0,0.06)  (18x)
- #080808  (8x)
- #050505  (6x)
- #0a0a0a  (3x)
- rgba(0,0,0,0.1)  (3x)
- rgba(25,28,33,0.02)  (3x)
- rgba(25,28,33,0.08)  (3x)
- #18181b  (2x)
- #27272a  (1x)
- #3f3f46  (1x)
- #202024  (1x)
- #101014  (1x)
- rgba(0, 0, 0, 0.034)  (1x)
- rgba(0, 0, 0, 0.048)  (1x)
- rgba(0, 0, 0, 0.06)  (1x)
- rgba(0, 0, 0, 0.072)  (1x)

## Tipografia detectada
- Geist
- JetBrains Mono

## Estrutura de seções
- Turn audience trust into scalable software. Mapping distribution to absolute precision.
- Calibrated to your exact parameters.
- Ready to eliminate the latency between audience and product?

## Regras de implementação
- O `index.html` do template é a fonte principal de verdade.
- Não simplificar a identidade visual: manter imagens, gradientes, cards,
  overlays, efeitos e ritmo da copy.
- Ao converter para React, chegar ao resultado fiel antes de refatorar
  em componentes.
- Trocar apenas textos, links e imagens necessários ao novo negócio.
- Nunca inserir número que o negócio não tenha (avaliação, anos de
  mercado, nº de clientes). Dado não verificado não vai para o site.
