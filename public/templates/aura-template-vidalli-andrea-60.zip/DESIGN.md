# DESIGN.md — Luxury Jewelry E-commerce Template

Origem: registry privado 77lib
Slug: `aura-template-vidalli-andrea-60`

## Objetivo
A refined, artisanal jewelry e-commerce template featuring a minimalist aesthetic and high-end product showcases for sustainable luxury brands. Fonte: https://www.aura.build/templates/vidalli-andrea-60

## Direção visual
- Manter a composição original: proporções, ritmo vertical, blocos de
  conteúdo e atmosfera.
- Preservar hierarquia tipográfica, contraste, espaçamento, estados
  visuais e tratamento de imagens.
- Adaptar responsivamente sem descaracterizar o layout.

## Paleta detectada
- #c5a059  (1x)
- #dcc287  (1x)
- #a68545  (1x)
- #ffffff  (1x)
- rgb(197, 160, 89)  (1x)
- rgb(255, 255, 255)  (1x)

## Tipografia detectada
- Inter
- Playfair Display

## Estrutura de seções
- Westend Juwelier Haider
- Signature Pieces
- Vidalli Andrea Handwerk &amp; Seele

## Regras de implementação
- O `index.html` do template é a fonte principal de verdade.
- Não simplificar a identidade visual: manter imagens, gradientes, cards,
  overlays, efeitos e ritmo da copy.
- Ao converter para React, chegar ao resultado fiel antes de refatorar
  em componentes.
- Trocar apenas textos, links e imagens necessários ao novo negócio.
- Nunca inserir número que o negócio não tenha (avaliação, anos de
  mercado, nº de clientes). Dado não verificado não vai para o site.
