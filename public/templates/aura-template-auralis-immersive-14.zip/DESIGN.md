# DESIGN.md — Auralis Immersive Tech Landing Page Template

Origem: registry privado 77lib
Slug: `aura-template-auralis-immersive-14`

## Objetivo
A high-performance, dark-themed immersive landing page template featuring GSAP animations and Three.js visuals for visionaries and elite tech brands. Fonte: https://www.aura.build/templates/auralis-immersive-14

## Direção visual
- Manter a composição original: proporções, ritmo vertical, blocos de
  conteúdo e atmosfera.
- Preservar hierarquia tipográfica, contraste, espaçamento, estados
  visuais e tratamento de imagens.
- Adaptar responsivamente sem descaracterizar o layout.

## Paleta detectada
- #262626  (44x)
- #020617  (38x)
- #080808  (29x)
- #f97316  (18x)
- #429dfe  (11x)
- #ff91e3  (8x)
- #1a1a1a  (8x)
- #10b981  (4x)
- #f59e0b  (4x)
- #8b5cf6  (4x)
- #ef4444  (4x)
- #6366f1  (4x)
- #14b8a6  (4x)
- #ec4899  (4x)
- #ffffff  (2x)
- #d4d4d4  (2x)

## Tipografia detectada
- Geist

## Estrutura de seções
- GLOBAL
- NEXUS
- WHERE VISION MEETS
- ENGINEEREDFOR IMPACT
- THE SYNDICATEVOICES
- EXPAND YOUR HORIZON

## Regras de implementação
- O `index.html` do template é a fonte principal de verdade.
- Não simplificar a identidade visual: manter imagens, gradientes, cards,
  overlays, efeitos e ritmo da copy.
- Ao converter para React, chegar ao resultado fiel antes de refatorar
  em componentes.
- Trocar apenas textos, links e imagens necessários ao novo negócio.
- Nunca inserir número que o negócio não tenha (avaliação, anos de
  mercado, nº de clientes). Dado não verificado não vai para o site.
