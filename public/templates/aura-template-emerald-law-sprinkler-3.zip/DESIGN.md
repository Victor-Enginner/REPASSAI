# DESIGN.md — Smart Irrigation  Landscape Lighting Template

Origem: registry privado 77lib
Slug: `aura-template-emerald-law-sprinkler-3`

## Objetivo
A high-end, futuristic dark-themed template designed for professional landscaping, irrigation, and outdoor lighting service providers. Fonte: https://www.aura.build/templates/emerald-law-sprinkler-3

## Direção visual
- Manter a composição original: proporções, ritmo vertical, blocos de
  conteúdo e atmosfera.
- Preservar hierarquia tipográfica, contraste, espaçamento, estados
  visuais e tratamento de imagens.
- Adaptar responsivamente sem descaracterizar o layout.

## Paleta detectada
- #149116  (58x)
- #0f0f0f  (25x)
- #deb40f  (14x)
- #141414  (11x)
- #117a12  (4x)
- rgba(20,145,22,0.3)  (4x)
- rgba(255,255,255,0.8)  (2x)
- rgba(20,145,22,0.5)  (2x)
- rgba(255,255,255,0.4)  (2x)
- #1a1a1a  (1x)
- rgba(0,0,0,0.5)  (1x)

## Tipografia detectada
- Inter

## Estrutura de seções
- Smarter Water, Greener Lawns .
- Intelligent Systems For Modern Landscapes
- Trusted By Homeowners
- Request A Free Estimate

## Regras de implementação
- O `index.html` do template é a fonte principal de verdade.
- Não simplificar a identidade visual: manter imagens, gradientes, cards,
  overlays, efeitos e ritmo da copy.
- Ao converter para React, chegar ao resultado fiel antes de refatorar
  em componentes.
- Trocar apenas textos, links e imagens necessários ao novo negócio.
- Nunca inserir número que o negócio não tenha (avaliação, anos de
  mercado, nº de clientes). Dado não verificado não vai para o site.
