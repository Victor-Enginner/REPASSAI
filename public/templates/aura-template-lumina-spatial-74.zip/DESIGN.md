# DESIGN.md — Lumina AI  Spatial Computing Landing Page Template

Origem: registry privado 77lib
Slug: `aura-template-lumina-spatial-74`

## Objetivo
A high-end futuristic landing page template designed for neural networks, spatial computing, and AI architecture companies. Fonte: https://www.aura.build/templates/lumina-spatial-74

## Direção visual
- Manter a composição original: proporções, ritmo vertical, blocos de
  conteúdo e atmosfera.
- Preservar hierarquia tipográfica, contraste, espaçamento, estados
  visuais e tratamento de imagens.
- Adaptar responsivamente sem descaracterizar o layout.

## Paleta detectada
- #030303  (22x)
- #22d3ee  (6x)
- #09090b  (5x)
- rgba(34,211,238,0.2)  (4x)
- #050505  (3x)
- rgba(0,229,255,0.8)  (3x)
- #f4f4f5  (2x)
- #00e5ff  (2x)
- rgba(34, 211, 238, 0)  (2x)
- rgba(34, 211, 238, 0.08)  (2x)
- rgba(34, 211, 238, 0.18)  (2x)
- rgba(34, 211, 238, 0.95)  (2x)
- rgba(34, 211, 238, 0.28)  (2x)
- rgba(0, 0, 0, 0.55)  (2x)
- rgba(0,229,255,0.08)  (2x)
- rgba(0,229,255,0.4)  (2x)

## Tipografia detectada
- Inter
- JetBrains Mono

## Estrutura de seções
- SYNTHESIS IS OUR CATALYST
- ELEVATING COGNITIVE STRUCTURES
- GLOBAL DATA STREAMS
- PROVEN ARCHITECTURES
- INITIATE YOUR SEQUENCE

## Regras de implementação
- O `index.html` do template é a fonte principal de verdade.
- Não simplificar a identidade visual: manter imagens, gradientes, cards,
  overlays, efeitos e ritmo da copy.
- Ao converter para React, chegar ao resultado fiel antes de refatorar
  em componentes.
- Trocar apenas textos, links e imagens necessários ao novo negócio.
- Nunca inserir número que o negócio não tenha (avaliação, anos de
  mercado, nº de clientes). Dado não verificado não vai para o site.
