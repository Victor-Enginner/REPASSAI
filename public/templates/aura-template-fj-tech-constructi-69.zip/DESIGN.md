# DESIGN.md — Architecture  Construction Firm Portfolio Template

Origem: registry privado 77lib
Slug: `aura-template-fj-tech-constructi-69`

## Objetivo
A high-end, professional portfolio template designed for architecture and construction firms to showcase luxury renovations and large-scale projects. Fonte: https://www.aura.build/templates/fj-tech-constructi-69

## Direção visual
- Manter a composição original: proporções, ritmo vertical, blocos de
  conteúdo e atmosfera.
- Preservar hierarquia tipográfica, contraste, espaçamento, estados
  visuais e tratamento de imagens.
- Adaptar responsivamente sem descaracterizar o layout.

## Paleta detectada
- #27272a  (17x)
- #818cf8  (13x)
- #a1a1aa  (10x)
- #0e0e10  (5x)
- #18181c  (4x)
- #f472b6  (4x)
- #fcfcfc  (2x)
- #fff  (2x)
- #171717  (1x)
- #e5e5e5  (1x)
- #000  (1x)
- #d4d4d4  (1x)
- #a3a3a3  (1x)
- rgba(0,0,0,0.5)  (1x)
- rgba(0,0,0,0.3)  (1x)
- rgba(0,0,0,0.15)  (1x)

## Tipografia detectada
- Inter
- JetBrains Mono

## Estrutura de seções
- Building Tomorrow's Heritage.
- Selected Projects
- Executive Financial Summary

## Regras de implementação
- O `index.html` do template é a fonte principal de verdade.
- Não simplificar a identidade visual: manter imagens, gradientes, cards,
  overlays, efeitos e ritmo da copy.
- Ao converter para React, chegar ao resultado fiel antes de refatorar
  em componentes.
- Trocar apenas textos, links e imagens necessários ao novo negócio.
- Nunca inserir número que o negócio não tenha (avaliação, anos de
  mercado, nº de clientes). Dado não verificado não vai para o site.
