# DESIGN.md — Luxury Nature Lodge Landing Page Template

Origem: registry privado 77lib
Slug: `aura-template-luxury-eco-lodge-66`

## Objetivo
A high-end vacation rental and hospitality template designed for luxury eco-lodges, cabins, and boutique nature resorts. Fonte: https://www.aura.build/templates/luxury-eco-lodge-66

## Direção visual
- Manter a composição original: proporções, ritmo vertical, blocos de
  conteúdo e atmosfera.
- Preservar hierarquia tipográfica, contraste, espaçamento, estados
  visuais e tratamento de imagens.
- Adaptar responsivamente sem descaracterizar o layout.

## Paleta detectada
- #282828  (3x)
- #555b00  (2x)
- #f6efe5  (2x)
- #ada89a  (2x)
- #be7f00  (1x)
- #1e1e1e  (1x)
- #25d366  (1x)
- #128c7e  (1x)
- rgba(85, 91, 0, 0.18)  (1x)
- rgba(0, 0, 0, 0.36)  (1x)

## Tipografia detectada
- Playfair Display
- Public Sans

## Estrutura de seções
- Refugio de Exclusividad
- Catálogo de Amenidades
- Distribución de Habitaciones
- Nuestra Fauna
- Tarifas Planas
- Reglas de Convivencia
- Interacción con la Fauna
- Tour 360°
- Solicitud de Reserva
- Ubicación Estratégica

## Regras de implementação
- O `index.html` do template é a fonte principal de verdade.
- Não simplificar a identidade visual: manter imagens, gradientes, cards,
  overlays, efeitos e ritmo da copy.
- Ao converter para React, chegar ao resultado fiel antes de refatorar
  em componentes.
- Trocar apenas textos, links e imagens necessários ao novo negócio.
- Nunca inserir número que o negócio não tenha (avaliação, anos de
  mercado, nº de clientes). Dado não verificado não vai para o site.
