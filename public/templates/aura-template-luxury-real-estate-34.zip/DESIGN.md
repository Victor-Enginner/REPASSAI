# DESIGN.md — Luxury Real Estate Landing Page Template

Origem: registry privado 77lib
Slug: `aura-template-luxury-real-estate-34`

## Objetivo
A high-end, premium landing page template designed for luxury residences and real estate investment projects, featuring multi-theme support and immersive animations. Fonte: https://www.aura.build/templates/luxury-real-estate-34

## Direção visual
- Manter a composição original: proporções, ritmo vertical, blocos de
  conteúdo e atmosfera.
- Preservar hierarquia tipográfica, contraste, espaçamento, estados
  visuais e tratamento de imagens.
- Adaptar responsivamente sem descaracterizar o layout.

## Paleta detectada
- rgba(193,127,89,0.3)  (16x)
- rgba(193,127,89,0.1)  (13x)
- #fff  (12x)
- rgba(193,127,89,0.06)  (12x)
- #f5f0eb  (11x)
- rgba(193,127,89,0.2)  (11x)
- rgba(193,127,89,0.08)  (10x)
- rgba(193,127,89,0.25)  (8x)
- rgba(193,127,89,0.15)  (7x)
- rgba(0,0,0,0.4)  (3x)
- #0f0f0e  (2x)
- #1a1917  (2x)
- #6b675e  (2x)
- rgba(212,160,122,0.7)  (2x)
- rgba(15,15,14,0.55)  (2x)
- rgba(193,127,89,0.12)  (2x)

## Tipografia detectada
- Inter
- Playfair Display

## Estrutura de seções
- Première ligne à Sotchi
- Un nouveau niveau de vie balnéaire
- Collection d’appartements
- Un modèle transparent
- Le projet se distingue par une grande variété de plans
- Finitions irréprochables
- Investissez dans le resort du futur

## Regras de implementação
- O `index.html` do template é a fonte principal de verdade.
- Não simplificar a identidade visual: manter imagens, gradientes, cards,
  overlays, efeitos e ritmo da copy.
- Ao converter para React, chegar ao resultado fiel antes de refatorar
  em componentes.
- Trocar apenas textos, links e imagens necessários ao novo negócio.
- Nunca inserir número que o negócio não tenha (avaliação, anos de
  mercado, nº de clientes). Dado não verificado não vai para o site.
