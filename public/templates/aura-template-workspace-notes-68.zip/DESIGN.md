# DESIGN.md — Notebook Workspace App Template

Origem: registry privado 77lib
Slug: `aura-template-workspace-notes-68`

## Objetivo
A reusable template for building a clean, Notion-style workspace and document editor UI with sidebar navigation, rich text controls, and collaborative actions. Fonte: https://www.aura.build/templates/workspace-notes-68

## Direção visual
- Manter a composição original: proporções, ritmo vertical, blocos de
  conteúdo e atmosfera.
- Preservar hierarquia tipográfica, contraste, espaçamento, estados
  visuais e tratamento de imagens.
- Adaptar responsivamente sem descaracterizar o layout.

## Paleta detectada
- rgba(24,24,27,0.08)  (10x)
- rgba(24,24,27,0.05)  (8x)
- #fbfbfc  (4x)
- rgba(24,24,27,0.1)  (4x)
- rgba(24,24,27,0.04)  (3x)
- rgba(255,255,255,0.8)  (2x)
- rgba(22,163,74,0.4)  (2x)
- #e4e4e7  (1x)
- #d4d4d8  (1x)
- #a1a1aa  (1x)
- rgba(255,255,255,0.4)  (1x)
- rgba(24,24,27,0.3)  (1x)
- rgb(0,0,0,0.12)  (1x)
- rgb(0,0,0,0.16)  (1x)

## Tipografia detectada
- Inter

## Estrutura de seções
- Product Roadmap Q3
- # Key Initiatives

## Regras de implementação
- O `index.html` do template é a fonte principal de verdade.
- Não simplificar a identidade visual: manter imagens, gradientes, cards,
  overlays, efeitos e ritmo da copy.
- Ao converter para React, chegar ao resultado fiel antes de refatorar
  em componentes.
- Trocar apenas textos, links e imagens necessários ao novo negócio.
- Nunca inserir número que o negócio não tenha (avaliação, anos de
  mercado, nº de clientes). Dado não verificado não vai para o site.
