# DESIGN.md — Women's Empowerment Networking Template

Origem: registry privado 77lib
Slug: `aura-template-women-s-community-0`

## Objetivo
A sophisticated, community-focused landing page template designed for networking groups, women-led organizations, and podcasters. Fonte: https://www.aura.build/templates/women-s-community-0

## Direção visual
- Manter a composição original: proporções, ritmo vertical, blocos de
  conteúdo e atmosfera.
- Preservar hierarquia tipográfica, contraste, espaçamento, estados
  visuais e tratamento de imagens.
- Adaptar responsivamente sem descaracterizar o layout.

## Paleta detectada
- #1a1a2e  (31x)
- #ca9667  (24x)
- #d3ad3b  (11x)
- #fafaf7  (11x)
- #2b2825  (9x)
- #ffffff  (2x)

## Tipografia detectada
- Playfair Display
- Raleway

## Estrutura de seções
- You're doing so much. And still, something's missing.
- This space was built for exactly this.
- Four pillars. One whole-woman conversation.
- A peer who became a builder.
- Real conversations, every week.
- A room full of women who get it.

## Regras de implementação
- O `index.html` do template é a fonte principal de verdade.
- Não simplificar a identidade visual: manter imagens, gradientes, cards,
  overlays, efeitos e ritmo da copy.
- Ao converter para React, chegar ao resultado fiel antes de refatorar
  em componentes.
- Trocar apenas textos, links e imagens necessários ao novo negócio.
- Nunca inserir número que o negócio não tenha (avaliação, anos de
  mercado, nº de clientes). Dado não verificado não vai para o site.
