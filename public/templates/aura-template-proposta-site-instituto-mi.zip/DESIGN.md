# DESIGN.md — Proposta Instituto Mineiro de Serviços Odontologia

Origem: registry privado 77lib
Slug: `aura-template-proposta-site-instituto-mi`

## Objetivo
Cuidado imediato, estrutura completa e profissionais preparados para atender você todos os dias, inclusive finais de semana e feriados. Fonte: https://www.aura.build/templates/proposta-site-instituto-mi

## Direção visual
- Manter a composição original: proporções, ritmo vertical, blocos de
  conteúdo e atmosfera.
- Preservar hierarquia tipográfica, contraste, espaçamento, estados
  visuais e tratamento de imagens.
- Adaptar responsivamente sem descaracterizar o layout.

## Paleta detectada
- #0b2f4a  (26x)
- #7a1e3a  (20x)
- #1f2933  (18x)
- #25d366  (11x)
- #fbe8ec  (8x)
- #4a1024  (7x)
- #f7f1ea  (7x)
- rgba(31,41,51,0.06)  (6x)
- #ffffff  (5x)
- #1d75a6  (5x)
- rgba(0,0,0,0)  (5x)
- #fff  (4x)
- rgba(122,30,58,0.25)  (4x)
- #ddf3fa  (3x)
- #f5f7fa  (2x)
- rgba(122,30,58,.14)  (2x)

## Tipografia detectada
- Inter
- Playfair Display
- Geist
- Sora

## Estrutura de seções
- Atendimento odontológico 24h
- Confiança Clínica e Resposta Rápida
- Um centro de referência em urgência odontológica
- Serviços de urgência
- Dúvidas frequentes
- Precisa de Atendimento Agora?
- Dúvidas Frequentes
- Depoimentos
- Contato e localização

## Regras de implementação
- O `index.html` do template é a fonte principal de verdade.
- Não simplificar a identidade visual: manter imagens, gradientes, cards,
  overlays, efeitos e ritmo da copy.
- Ao converter para React, chegar ao resultado fiel antes de refatorar
  em componentes.
- Trocar apenas textos, links e imagens necessários ao novo negócio.
- Nunca inserir número que o negócio não tenha (avaliação, anos de
  mercado, nº de clientes). Dado não verificado não vai para o site.
