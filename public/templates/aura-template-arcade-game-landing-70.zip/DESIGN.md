# DESIGN.md — Arcade Game Landing Page Template

Origem: registry privado 77lib
Slug: `aura-template-arcade-game-landing-70`

## Objetivo
A reusable landing page template for showcasing a browser-based arcade game with interactive gameplay, score tracking, and a bold dark UI. Fonte: https://www.aura.build/templates/arcade-game-landing-70

## Direção visual
- Manter a composição original: proporções, ritmo vertical, blocos de
  conteúdo e atmosfera.
- Preservar hierarquia tipográfica, contraste, espaçamento, estados
  visuais e tratamento de imagens.
- Adaptar responsivamente sem descaracterizar o layout.

## Paleta detectada
- #ffffff  (14x)
- rgba(255, 255, 255, 0.6)  (6x)
- #09090b  (5x)
- rgba(255,255,255,0.03)  (4x)
- rgba(250,204,21,0.5)  (4x)
- rgba(255, 255, 255, 0.15)  (3x)
- #422006  (2x)
- rgba(255,255,255,0.02)  (2x)
- rgba(0,0,0,0.15)  (2x)
- rgba(161,161,170,0.2)  (2x)
- rgba(232,121,249,0.5)  (2x)
- #fff  (1x)
- #10b981  (1x)
- #2e1065  (1x)
- #083344  (1x)
- #451a03  (1x)

## Tipografia detectada
- Inter

## Estrutura de seções
- Geometry Dash
- Settings
- Customize

## Regras de implementação
- O `index.html` do template é a fonte principal de verdade.
- Não simplificar a identidade visual: manter imagens, gradientes, cards,
  overlays, efeitos e ritmo da copy.
- Ao converter para React, chegar ao resultado fiel antes de refatorar
  em componentes.
- Trocar apenas textos, links e imagens necessários ao novo negócio.
- Nunca inserir número que o negócio não tenha (avaliação, anos de
  mercado, nº de clientes). Dado não verificado não vai para o site.
